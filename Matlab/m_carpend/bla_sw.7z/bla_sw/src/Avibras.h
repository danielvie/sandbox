  
/******************************************************************************
- TITULO       : Avibras.h
- PROPOSITO    : Definicao das funcoes utilizadas na extrapolacao
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 12/02/2015 - Flavio Nogueira, Daniel Vieira, Anderson Millan
- MODIFICACOES : -
*******************************************************************************/

#ifndef AVIBRAS_H
#define AVIBRAS_H

#include "estruturas.h"

#define STEP_VALUE	0.02
#define STEP_FAST	0.02

void av_init_bdt(AV_BDT *av_bdt, enum AV_RESULT *ret, struct TTelaEngenharia telaEngenharia);
void av_init(AV_STATE *av_state, condicaoInicial *inicio, enum AV_RESULT *ret);
void av_step(AV_STATE *av_state, enum AV_RESULT *ret, double *Fuse_o, double *Hejec_o, struct StatusStep *ststep);

double retornaTempo ();
void escreveTempo ();

const char *av_version(void);

#endif
