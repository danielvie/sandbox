
/******************************************************************************
- TITULO       : bradock.cpp
- PROPOSITO    :
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 08/12/2014 - Daniel Vieira, Anderson Millan
- MODIFICACOES : -
*******************************************************************************/

#include "bradock.h"

double bradock::produtoEscalar(double *x,double *y){
	double ret = (x[0]*y[0]+x[1]*y[1]+x[2]*y[2]);
	return ret;
}

double bradock::norma(double *x){
	// retorna a norma do vetor x[3]
	double ret = sqrt(bradock::produtoEscalar(x,x));
	return ret;
}

double bradock::produtoVetorial(double *x,double *y, int el){
	// calcula produto vetorial
	double res; // vetor resposta
	switch (el) {
		case 1:
			res = (x[1]*y[2] - x[2]*y[1]);
			break;
		case 2:
			res = (x[2]*y[0] - x[0]*y[2]);
			break;
		case 3:
			res = (x[0]*y[1] - x[1]*y[0]);
			break;
		default:
			res = 0;
			break;
	}
	return res;
}

int bradock::minimo(double *x, int tam){
	// encontra o valor minimo do vetor
	double aux = x[0];
	int cont = 0;

	for (int i = 0; i < tam; ++i) {
		if (x[i]<aux){
			aux = x[i];
			cont = i;
		}
	}
	return cont;
}

double bradock::arredonda(double x){
	// arredonda X
	double aux = (double)((int)x);
	double ret = (x - aux >= 0.5001)?(aux + 1):(aux);
	return ret;
}

double bradock::trunca(double x){
	// arredonda X
	double aux = (double)((int)x);
	double ret = aux;
	return ret;
}

double bradock::contaDoZe(double *origem, double *fim){
	// % funcao em MATLAB para calculo do angulo de Azimute
	// function [ZE,ZE_mils] = conta_do_ze(LAN,REF)
	//    v2      = [0,1];
	//    v1      = REF-LAN;
	//	  ZE      = acosd(dot(v1,v2)/norm(v1)/norm(v2));
	//    sig     = cross([v2 0],[v1 0]);
	//    sig     = sign(sig(3));
	//    if sig > 0; ZE = 360-ZE; end;
	//    ZE_mils = ZE/0.05625;
	double v1[3], v2[3] = {0, 1, 0};
	double ang;

	v1[0] = fim[0] - origem[0];
	v1[1] = fim[1] - origem[1];
	v1[2] = 0;

	// produto escalar para encontrar o angulo
	ang   = acos(bradock::produtoEscalar(v1,v2)/bradock::norma(v1)/bradock::norma(v2));
	// produto vetorial para encontrar o sinal
	ang   = ((v1[1]*v2[0] - v1[0]*v2[1])>1)?(2*3.14159265359-ang):ang;

	return ang;
}

int bradock::sinal(double nro){
	// encontrando sinal do nro
	// entra o double com o nro e retorna int com o sinal
	int ret = (nro >= 0) ? 1:-1;
	return ret;
}

//double bradock::absoluto(double nro){
//	// retorna valor absoluto
//	double ret = (nro < 0)?-nro:nro;
//	return ret;
//}
