
/******************************************************************************
- TITULO       : f_custo.cpp
- PROPOSITO    :
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 11/12/2014 - Daniel Vieira, Anderson Millan
- MODIFICACOES : -
*******************************************************************************/

#include "f_custo.h"
#include "novaedt.h"

double f_custo(double x[], void *params) {
	struct TShot shot;
	double elevacao, azimute;

	elevacao = x[0];

	novaEdt* sansao = (novaEdt*)params;

	if (elevacao < sansao->DDTDLL.Elev_min)
		return 1e8;
	if (elevacao > sansao->DDTDLL.Elevmax/0.05625) // caso de elevacao maxima
		return 1e8;

	sansao->edtData.Elev_tiro = elevacao;

	azimute = sansao->edtData.Azim_tiro;

	// Condicao inicial
	shot = sansao->voarCompleto();

	//	ENCONTRAR O DESVIO ALCANCE E LATERAL
	double desvAlc = sansao->calcularDesvioAlcance();
	double desvLat = sansao->calcularDesvioLateral();

	double erroAlc = fabs(desvAlc);
	double erro = erroAlc;

	// ajuste azimute
	double ajusteAzi = desvLat/sansao->calcularAlcance()*1000;

	azimute -= ajusteAzi;
	sansao->edtData.Azim_tiro = azimute;

	if(shot.Error == BALISTIC_ERROR002) // caso de nao conseguir fazer a ejecao
		erro += 1e5;

	return erro;
}

double f_custo_ventoth(double x[], void *params) {
	double ventoE,ventoN;
	ventoE = x[0];
	ventoN = x[1];

	novaEdt *sansao = (novaEdt*)params;

	// Condicao inicial
	sansao->edtData.Vweth = ventoE;
	sansao->edtData.Vwnth = ventoN;

	// fazendo a diferenca dos ventos em 2x o tempo de queima do foguete
	// isso foi passado pelo Ricardo P. durante os testes o radar com o
	// Flavio e o Derso. A mudanca eh  para que o vento TH represente a
	// fase de voo do foguete com maior variacao de velocidade, deixando
	// o vento FF para a fase do voo com velocidade mais constante;
	sansao->voarCompleto(sansao->tempoQueima*2);

	//	ENCONTRAR O DESVIO ALCANCE E LATERAL

	double diferenca[3] = {sansao->stState.VXN-sansao->velocidadeFimDeQueima[0],sansao->stState.VYN-sansao->velocidadeFimDeQueima[1],sansao->stState.VZN-sansao->velocidadeFimDeQueima[2]};
	double erro = diferenca[0]*diferenca[0] + diferenca[1]*diferenca[1] + diferenca[2]*diferenca[2];
	return erro;
}

double f_custo_ventoff(double x[], void *params) {
	double ventoE,ventoN;
	ventoE = x[0];
	ventoN = x[1];

	novaEdt *sansao = (novaEdt*)params;

	// Condicao inicial
	sansao->edtData.Vweff = ventoE;
	sansao->edtData.Vwnff = ventoN;

	sansao->voarCompleto();

	//	ENCONTRAR O DESVIO ALCANCE E LATERAL
	double diferenca[3] = {
			sansao->posicaoImpacto[0] - sansao->posicaoFimDeVoo[0],
			sansao->posicaoImpacto[1] - sansao->posicaoFimDeVoo[1],
			sansao->posicaoImpacto[2] - sansao->posicaoFimDeVoo[2]};

	double d1 = sqrt(diferenca[0]*diferenca[0]);
	double d2 = sqrt(diferenca[1]*diferenca[1]);
	double erro =  d1 + d2;

	return erro;
}

double f_custoAlcanceMaximo(double x[], void *params) {
	double elevacao, erro;
	elevacao = x[0];

	novaEdt *sansao = (novaEdt*)params;

	if (elevacao < 0 || elevacao > sansao->DDTDLL.Elevmax/0.05625)
		return 1e8;

	// calculando voo
	sansao->edtData.Elev_tiro = elevacao;
	sansao->voarCompleto();

	// calculando erro
	erro = 1/fabs(sansao->calcularAlcance())*1e5;

	if(sansao->Fusetime < 0.01) // caso de nao conseguir fazer a ejecao
		erro += 1e5;

	return erro;
}
