
/******************************************************************************
- TITULO       : estruturas.h
- PROPOSITO    : Arquivo de definicao de estruturas e constantes da DLL.
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 02/10/2014 - Daniel Vieira
- MODIFICACOES : 12/02/2015 - Flavio Nogueira
					Implementacoes para utilizacao na DLL utilizada pela CCT
*******************************************************************************/

#ifndef ESTRUTURAS_H_
#define ESTRUTURAS_H_

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

#define LOG_SIZE 1024

//Erros de trajetoria
#define BALISTIC_ERROR001 1 //ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DO ALVO
#define BALISTIC_ERROR002 2 //ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DE EJECAO
#define BALISTIC_ERROR003 3 //ALVO MUITO CURTO
#define BALISTIC_ERROR004 4 //ALVO MUITO LONGO

// ESTRUTURA EDTDATA
struct TEdtData {
	int DDTType; /* .5 */
	double Latitude; /* 1 */
	int Sec_bal, Metcm_included, Natm; /* 1.5 */
	double Vwmetcm[41], Azwmetcm[41], Tent[41], Pent[41]; /* 164 */
	double Alt_met, Azwcor, T0, P0, Proptemp, Vws, Azws, Altfg, RefDir; /* 9 */
	double Elau, Nlau, Alt_launch, Etarg, Ntarg, Altarg, Azim_tiro, Elev_tiro,
			Fusetime_input; /* 9 */
	double Vweth, Vwnth, Vweff, Vwnff;
	double Elev_max; /* 5 */
	int CalType; /*.5*/
};

// ESTRUTURA EXTRAPOLACAO
struct TExtrapolationData {
	double EImp, NImp, HImp;
	double VFQueima1, VFQueima2, VFQueima3;
	int Valido;
};

// ESTRUTURA DE TODA EXTRAPOLACAO
struct TStructExtrapolationData {
	double EImp[13], NImp[13], HImp[13];
	double VFQueima1[13], VFQueima2[13], VFQueima3[13];
	int Valido[13];
};

// VETOR DE ESTADOS
struct AV_STATE_DATA {
	double FLIGHT_TIMER_N;		/* Time since flash of measurment		[s] */
	double FLIGHT_TIMER_O;		/* Validity time of prediction	 (since flash)	[s] */

                                /* Predicted position */
	double XN;					/* CO-ORDINATE X NEW		[m] */
	double YN;					/* CO-ORDINATE Y NEW		[m] */
	double ZN;					/* CO-ORDINATE Z NEW		[m] */

	double VXN;					/* VELOCITY X NEW		[m/s] */
	double VYN;					/* VELOCITY Y NEW		[m/s] */
	double VZN;					/* VELOCITY Z NEW		[m/s] */

								/* Measured position	 */
	double XO;					/* CO-ORDINATE X OLD		[m] */
	double YO;					/* CO-ORDINATE Y OLD		[m] */
	double ZO;					/* CO-ORDINATE Z OLD		[m] */

	double VXO;					/* VELOCITY X OLD		[m/s] */
	double VYO;					/* VELOCITY Y OLD		[m/s] */
	double VZO;					/* VELOCITY Z OLD		[m/s] */

	double ZN_SPH;					/* SPHERIC VAL. OF Z NEW	[m] */
	double ZO_SPH;					/* SPHERIC VAL. OF Z OLD	[m] */

	int    MISSILE_OUT_OF_TUBE;
};
typedef struct AV_STATE_DATA AV_STATE;

// DADOS DE BALISTICA
struct AV_BALL_DATA {
	/*  The contents for this structure will be passed to RAD SCC as data
	 *  part of message FIRING ELEMNTS (ID=13)
	 */
	char RAW_DATA[65000];
	int LENGTH;
};
typedef struct AV_BALL_DATA AV_BDT;

// CONDICAO INICIAL
struct _condicaoInicial {
	int extrapolar;
	double tempo;
	double pos[3];
	double vel[3];
};
typedef struct _condicaoInicial condicaoInicial;

struct TDDT
{
	double Mass, Propmass, Laul, Diaref; /* 4 */
	long N_points; /*.5*/
	double Ass, Pnom, Emp, Elevmax, Elev_tat, Elev_min, Vwmax, Cdadj, Cdadjsm, Fpon; /* 10 */
	double T_emp_step[21], P_emp_tp[6][21]; /* 147 */
	double V0_el[4], V0_tp[4], T0_el[4], T0_tp[4]; /* 16 */
	double Hejec1[6], Hejec2[6], Delta_ejec, Bwiwe[7], Hmthph[6], Cwss[41]; /* 67 */
	double Elcor[4][10], Azcor[4][10], Velcor[4][10]; /* 120 */
	double Elbas[4], Azbas[4], Velbas[4]; /* 12 */
	double El_to;
	double Fuzecor1[4], Fuzecor2[4]; /* 9 */
};

enum AV_RESULT {
	AV_OK,
	AV_FAILED
};

// status ejecao
struct StatusStep {
	int flagEjec; // flag indicando se houve ejecao
	double tejec; // tempo da ejecao
	double hejec; // altura da ejecao
};
    
#define TRK_SIZE 14500
struct TTrackingResult {
	char MissionState[TRK_SIZE][18];
	char MeasuredPositionState[TRK_SIZE][15];
	double MeasuredPositionX[TRK_SIZE];
	double MeasuredPositionY[TRK_SIZE];
	double MeasuredPositionZ[TRK_SIZE];
	double OneSigmaX[TRK_SIZE];
	double OneSigmaY[TRK_SIZE];
	double OneSigmaZ[TRK_SIZE];
	double SignalToNoiseRatio[TRK_SIZE];
	double FilteredPositionX[TRK_SIZE];
	double FilteredPositionY[TRK_SIZE];
	double FilteredPositionZ[TRK_SIZE];
	double FilteredVelocityX[TRK_SIZE];
	double FilteredVelocityY[TRK_SIZE];
	double FilteredVelocityZ[TRK_SIZE];
	int RelativeTime[TRK_SIZE];
};

struct TShot {
  int ShotNo;
  double Az, El, Fuse, Range; // elementos de tiro
  int Error; // erro
  double Apogee; // apogeu
  double Tf; // tempo final
  int flagEjec; // indicacao de ejecao
  double tejec; // tempo da ejecao
  double hejec; // altura da ejecao
};

struct TRetTraj {
  double Eimp, Nimp, Altarg, IRange, Dx_id, Dy_id, FTime;
  int Error;
};

struct TRetMaxRange {
  double Mr_qe, Max_rge;
};

struct TTelaEngenharia {
	double Delta_x_e_i;
	double Delta_y_e_i;
	double Delta_z_e_i;
	double Delta_vx_e_i;
	double Delta_vy_e_i;
	double Delta_vz_e_i;
	double Cd_fac_e_i;
	double Cdsm_fac_e_i;
	double Thrust_fac_e_i;
	double Tubetime_e_i;
	double Delta_ejec_e_i;
	double Mass_e_i;
	double Propmass_e_i;
	double Hejec_e_i;
};

#endif /* ESTRUTURAS_H_ */
