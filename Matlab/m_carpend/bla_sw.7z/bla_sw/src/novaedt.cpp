
/******************************************************************************
- TITULO       : novaedt.c
- PROPOSITO    : Arquivo com funcoes da classe novaEdt.
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 02/10/2014 - Daniel Vieira
- MODIFICACOES : 12/02/2015 - Flavio Nogueira
					Implementacoes para utilizacao na DLL utilizada pela CCT
			   : 02/05/2016 - Flavio Nogueira
					Adicionado o foguete 40G
*******************************************************************************/

#include "novaedt.h"

novaEdt::novaEdt( void ) {
	this->T = 0;
	this->Hejec = 0;
	this->Fusetime = 0;

	this->Vweth = 0;
	this->Vwnth = 0;
	this->Vweff = 0;
	this->Vwnff = 0;

	this->apogeu = 0;
	this->range_apogeu = 0;

	this->crc_tab32_init = FALSE;
	this->ret = AV_OK;

	this->DDTDLL = this->SetDataDDT(1);
	this->tempoQueima = this->DDTDLL.T_emp_step[this->DDTDLL.N_points]*STEP_VALUE*(.25/STEP_VALUE);
	this->tempoFimSimulacao = 500;

	this->bEdtDataReceived = FALSE;
	this->bTrackingDataReceived = FALSE;

	this->CntTrkData = 0;
	this->bDebug = 0;
	this->ExtrapolationStart = 0;

	//Define e cria diretorio de saida dos logs
	GetModuleFileName(NULL,strOutDir,MAX_PATH);
	char *strOutDir2 = strrchr(strOutDir,'\\');
	if (strOutDir2) *strOutDir2 = '\0';
	strcat(strOutDir,"\\Log\\");
	mkdir(strOutDir);

	// Preenchedo um do campos da estrutura com valores conhecidos.
	//for (int var = 0; var <= TRK_SIZE; ++var)
	//	this->TrackingData.RelativeTime[var] = -1;

	// Inicializando rangeMin rangeMax
	this->rangeMin = 0;
	this->rangeMax = 0;

	// Inicializando telaEngenharia
	this->telaEngenharia.Delta_x_e_i    = 1.E+38;
	this->telaEngenharia.Delta_y_e_i    = 1.E+38;
	this->telaEngenharia.Delta_z_e_i    = 1.E+38;
	this->telaEngenharia.Delta_vx_e_i   = 1.E+38;
	this->telaEngenharia.Delta_vy_e_i   = 1.E+38;
	this->telaEngenharia.Delta_vz_e_i   = 1.E+38;
	this->telaEngenharia.Cd_fac_e_i     = 1.E+38;
	this->telaEngenharia.Cdsm_fac_e_i   = 1.E+38;
	this->telaEngenharia.Thrust_fac_e_i = 1.E+38;
	this->telaEngenharia.Tubetime_e_i   = 1.E+38;
	this->telaEngenharia.Delta_ejec_e_i = 1.E+38;
	this->telaEngenharia.Mass_e_i       = 1.E+38;
	this->telaEngenharia.Propmass_e_i   = 1.E+38;
	this->telaEngenharia.Hejec_e_i      = 1.E+38;
}

void novaEdt::ConfigEdt( int DDTType ) {
	this->crc_tab32_init = FALSE;
	this->ret = AV_OK;

	this->DDTDLL = this->SetDataDDT(DDTType);

	this->T = 0;

	this->tempoQueima = this->DDTDLL.T_emp_step[this->DDTDLL.N_points]*STEP_VALUE*(.25/STEP_VALUE);
	this->tempoFimSimulacao = 500;

	char txt[LOG_SIZE];
	sprintf(txt,"ConfigEdt: DDTType=%d; tempoQueima=%d; tempoFimSimulacao=%d\n",
			DDTType,(int)this->tempoQueima,(int)this->tempoFimSimulacao);
	print_debug(txt,false);
}

/* METODOS DANIEL */
struct TShot novaEdt::calcularTiro(void) {

	struct TShot shot;
	printf("entrei em calcularTiro\n");
	// shot = this->calcularTiro2();
	
	return shot;
}

struct TShot novaEdt::calcularTiro2(void) {
	// declaracao variaveis
	struct TShot shot;
	double distanciaAlvo;
	int erro;

	shot.Error = 0;

	//zerando o fuse time para fazer a estimativa correta de alcance maximo e minimo
	//Esse problema foi identificado pelo Derso e pelo Flavio testando varios tiros de foguetes seguidos
	//07/06/2016
	this->edtData.Fusetime_input = 1.e38;

	// calculando rangeMinMax
	this->calcularAlcanceMinimo();
	this->calcularAlcanceMaximo();
	
	// analise de erro
	distanciaAlvo = sqrt(
			  pow(this->edtData.Elau - this->edtData.Etarg, 2)
			+ pow(this->edtData.Nlau - this->edtData.Ntarg, 2));

	erro = 0;

	if (distanciaAlvo < this->rangeMin) {
		erro = BALISTIC_ERROR003;
	}

	// FALAMOS COM O RICARDO (DERSO E EU) SOBRE UM CASO QUE POR 4m NAO DARIA O TIRO, ENTAO FOI CONCLUIDO QUE SE USARIA UMA TOLERANCIA DE 50m
	// DEPOIS DESCOBRIMOS QUE EH MELHOR COLOCAR UMA PORCENTAGEM NO RANGE MAX, O PROBLEMA ACONTECE TAMBEM NO 60 E OS 50m NAO FOI SUFICIENTE
	if (distanciaAlvo > this->rangeMax + this->rangeMax*0.0035) {
		erro = BALISTIC_ERROR004;
	}

	// retornar erro se houver
	if (erro) {
		shot.Az    = 0;
		shot.El    = 0;
		shot.Fuse  = 0;
		shot.Error = erro;
		return shot;
	}

	// calculo do tiro
	shot = this->calcularTiro2_semRange();
	
	return shot;
}

struct TShot novaEdt::calcularTiro2_semRange(void) {
	struct TShot shot;
	double posicaoLancadora[3] = { this->edtData.Elau, this->edtData.Nlau, 0 };
	double posicaoAlvo[3] = { this->edtData.Etarg, this->edtData.Ntarg, 0 };

	// desvios e sensibilidade
	double desvioAlc, desvioLat, desvioAlc_, desvioLat_;
	double sensibilidade, minSensibilidade;
	double naoEjecao;
	// ajustes
	double ajusteAzi, ajusteEle, ajusteEleMax, alcance_, alcance, azimute, elevacao_, elevacao, elevMax;

	// contadores
	int i, contElevMax = 0, maxIter;

	// ajustando estimativas de ventos se calculados
	this->edtData.Vweth = this->Vweth; this->edtData.Vwnth = this->Vwnth;
	this->edtData.Vweff = this->Vweff; this->edtData.Vwnff = this->Vwnff;

	// encontrando elevacao max e desvios iniciais
	elevMax      = this->DDTDLL.Elevmax/0.05625;
	elevacao     = elevMax/2;
	ajusteEleMax = 100;
	azimute      = bradock::contaDoZe(posicaoLancadora,posicaoAlvo);
	azimute      = azimute*180/3.14159265359/0.05625; // convertendo para mils

	// fazendo voo piloto
	this->edtData.Elev_tiro = elevacao;
	this->edtData.Azim_tiro = azimute;
	this->voarCompleto();

	alcance_   = this->calcularAlcance();
	desvioAlc_ = this->calcularDesvioAlcance();
	desvioLat_ = this->calcularDesvioLateral();
	elevacao_  = this->edtData.Elev_tiro;

	// calculo sensibilidade elevacao inicial
	this->edtData.Elev_tiro = elevacao + 10;
	this->voarCompleto();
	alcance = this->calcularAlcance();
	sensibilidade = 10/fabs(alcance - alcance_);

	this->edtData.Elev_tiro = elevacao;

	// loop de calculo de apontamento
	int fim = 0;
	char msg[100];

	maxIter = 15;
	minSensibilidade = 0.001;
	naoEjecao = 1;

	// fazento o Fusetime_input = EMPTY
	this->edtData.Fusetime_input = 1.E+38;

	for (i = 0; i < maxIter; ++i) {
		// ajuste Azimute
		ajusteAzi = desvioLat_/alcance_*1000;
		azimute  -= ajusteAzi;
		this->edtData.Azim_tiro = azimute;

		// ajuste Elevacao
		ajusteEle  = desvioAlc_*sensibilidade;
		if(fabs(ajusteEle) > ajusteEleMax) // limitando ajuste de elevacao maximo
			ajusteEle = (bradock::sinal(ajusteEle) == 1)?ajusteEleMax:-ajusteEleMax;

		elevacao   = elevacao_ - ajusteEle * naoEjecao;

		// caso a elevacao esteja maior que a elevacao max
		if (elevacao > elevMax) {
			elevacao = elevMax;
			contElevMax++;
		}
		else contElevMax = 0;

		this->edtData.Elev_tiro = elevacao;

		// voo completo
		shot = this->voarCompleto();
		
		alcance   = this->calcularAlcance();
		desvioAlc = this->calcularDesvioAlcance();
		desvioLat = this->calcularDesvioLateral();

		// tratamento de apogeu < hejec
		if ((this->Fusetime < 0.01) & (this->edtData.Sec_bal != 0)){ // condicao em que sei que nao houve ejecao
			naoEjecao /= 2;
			continue;
		}

		else{
			naoEjecao = 1;
		}

		// atualizando elementos
		sensibilidade = fabs((elevacao - elevacao_)/(alcance - alcance_));

		if(sensibilidade < minSensibilidade) sensibilidade = minSensibilidade;

		// condicoes de interrupcao do loop
		if (fabs(desvioAlc - desvioAlc_) < 0.5 && fabs(desvioLat - desvioLat_) < 0.5) {
			sprintf(msg,"Interrupcao por diffAlcance < 1 e diffLat < 1\n");
			fim = 1;
		}

		if (contElevMax > 3){
			sprintf(msg,"\nInterrupcao por insistir em elevacao maior que a elevacao maxima!\n");
			fim = 1;
		}

		if (i >= maxIter-1){
			sprintf(msg,"\nInterrupcao por numero maximo de iteracoes!\n");
			fim = 1;
		}

		// atualizando variaveis
		elevacao_     = elevacao;
		alcance_      = alcance;
		desvioAlc_    = desvioAlc;
		desvioLat_    = desvioLat;

		// finalizando programa

		if(fim){
			this->edtData.Elev_tiro = bradock::arredonda(this->edtData.Elev_tiro);
			this->edtData.Azim_tiro = bradock::arredonda(this->edtData.Azim_tiro);
			shot = this->voarCompleto();
			// atualizando valor de fusetime para caso de FuseTime == 0
			if(this->Fusetime < 0.01) this->Fusetime = this->T;

			break;
		}
	}

	this->edtData.Fusetime_input = this->Fusetime;
	return shot;
}

/* get_coord_lmu
 * 
 * Retorna posicao da LMU
 * 
 * entrada: void
 * 
 * saida  : struct vetor_xyz
 * */
struct vetor_xyz novaEdt::get_coord_lmu(void){
	struct vetor_xyz v;
	
	v.x = this->edtData.Elau;
	v.y = this->edtData.Nlau;
	v.z = this->edtData.Alt_launch;

	return v;
}

/* get_coord_alvo
 * 
 * Retorna posicao do ALVO
 * 
 * entrada: void
 * 
 * saida  : struct vetor_xyz
 * */
struct vetor_xyz novaEdt::get_coord_alvo(void){
	struct vetor_xyz v;

	v.x = this->edtData.Etarg;
	v.y = this->edtData.Ntarg;
	v.z = this->edtData.Altarg;

	return v;
}

/* get_dist_alvo
 * 
 * Retorna distancia entre 'lmu' e 'alvo'
 * 
 * entrada: void
 * 
 * saida  : double
 * */
double novaEdt::get_dist_alvo(void){
	struct vetor_xyz lmu, alvo;
	double dist;

	lmu    = this->get_coord_lmu();
	lmu.z  = 0.0;
	alvo   = this->get_coord_alvo();
	alvo.z = 0.0;

	dist = sansao::norma_v(sansao::sub(lmu, alvo));

	return dist;
}

/* calcularTiro_dx
 * 
 * Calcula os elementos de tiro para posicao de alvo a 'dx' metros a frente
 * do alvo atual, na direcao da DGT
 * 
 * entrada: void
 * 
 * saida  : struct TShot
 * */
struct TShot novaEdt::calcularTiro_dx(double dx) {
	// TODO: criar testes funcionais
	// declarando variaveis
	struct TShot shot;
	struct vetor_xyz lmu, alvo, alvo_novo, V;
	double r;

	// lendo posicao lmu em vetor
	lmu = this->get_coord_lmu();
	
	// lendo posicao alvo em vetor
	alvo = this->get_coord_alvo();

	// Vetor diferenca
	V = sansao::sub(alvo, lmu);

	// calcular range
	r = sansao::norma_v(V);

	// calcular alvo novo { alvo_novo = V/norm(r)*(norm(r) + dx) + lmu }
	alvo_novo = sansao::add(sansao::mul(sansao::div(V,r), r + dx), lmu);

	// escrevendo alvo novo para calculo de tiro
	this->edtData.Etarg  = alvo_novo.x;
	this->edtData.Ntarg  = alvo_novo.y;
	this->edtData.Altarg = alvo_novo.z;

	// calculando valor de tiro
	shot = this->calcularTiro2();

	// restaurando alvo antigo
	this->edtData.Etarg  = alvo.x;
	this->edtData.Ntarg  = alvo.y;
	this->edtData.Altarg = alvo.z;

	// retorno da funcao
	return shot;
}

/* calcularTiro_ss40g
 * 
 * Calcula os elementos de tiro para ss40g
 * 
 * entrada: void
 * 
 * saida  : struct TShot
 * */
struct TShot novaEdt::calcularTiro_ss40g(void) {
	// TODO: criar testes funcionais

	// declarando variaveis
	double dist_alvo, dx, midx, madx, mi, ma;
	double a, b;

	struct TShot shot;

	// calculando coeficientes
	ma   = 33000.0;
	mi   = 22000.0;
	madx = 1200.0;
	midx = 700.0;

	a  = (madx - midx) / (ma - mi);
	b  = madx - ma * a;

	// calculando alcance
	dist_alvo = this->get_dist_alvo();
	
	// calculando distancia do alvo
	dx = a*dist_alvo + b;

	// saturador
	if (dx < midx) {
		dx = midx;
	}
	if (dx > madx) {
		dx = madx;
	}

	// calculando tiro
	shot = this->calcularTiro_dx(dx);

	if (shot.Error) {
		return shot;
	}

	// retorno da funcao
	return shot;
}

struct TShot novaEdt::calcularTiroObservador(void) {
	double alvoVerdadeiro[2];
	struct TShot shot;

	// salvando posicao alvo original
	alvoVerdadeiro[0] = this->edtData.Etarg;
	alvoVerdadeiro[1] = this->edtData.Ntarg;

	this->edtData.Etarg -= this->pontoObservado[0]-this->edtData.Etarg;
	this->edtData.Ntarg -= this->pontoObservado[1]-this->edtData.Ntarg;
	shot = this->calcularTiro2_semRange();

	// retornando posicao alvo original
	this->edtData.Etarg = alvoVerdadeiro[0];
	this->edtData.Ntarg = alvoVerdadeiro[1];
	return shot;
}

void novaEdt::calcularAlcanceMinimo(void) {
	// declarando variaveis
	struct TShot shot;
	int maxiter = 100;
	int i;

	// lendo valor de elevacao minima da DDT
	const double elevmin = this->DDTDLL.Elev_min;
	
	// guardando valor de elevacao inicial
	const double elev_ini = this->edtData.Elev_tiro;

	// calculando voo elevmin
	this->edtData.Elev_tiro = elevmin;
	shot = this->voarCompleto();
	 
	// calculando voo min secbal 1 se nao houve ejecao em `elemin`
	if ((this->edtData.Sec_bal > 0) && (shot.flagEjec == 0)) {

		for (i = 0; i < maxiter; i++) {			
			// incrementando elevacao e testando voo
			this->edtData.Elev_tiro += 1.0;
			shot = this->voarCompleto();

			// condicao de parada
			if (shot.flagEjec) {
				break;
			}
		}
	}

	// salvando rangemin
	this->rangeMin = shot.Range;
	
	// restaurando valores
	this->edtData.Elev_tiro = elev_ini;

}

struct TRetMaxRange novaEdt::calcularAlcanceMaximo(void) {
	// retornando valor de elevacao para anterior
	double elevacao_;
	elevacao_ = this->edtData.Elev_tiro;

	// Calculo dos elementos de tiro pelo algoritmo NELDER-MEAD (SIMPLEX)
	double start[1] = {700.0};
    double xmin[1];
    double ynewlo;
    double reqmin  = 1e-1;
    double step[1] = {100};
    double konvge  = 5;
    double kcount  = 100;
    int   icount;
    int   numres;
    int   ifault;
    int   n = 1;

	nelmin(f_custoAlcanceMaximo,this,n,start,xmin,&ynewlo,reqmin,step,konvge,kcount,&icount,&numres,&ifault);

	// this->otimin1(this->DDTDLL.Elevmax / 2 / 0.05625, 50, 1.5, &f_custoAlcanceMaximo);

	struct TRetMaxRange ret;
	ret.Max_rge = this->calcularAlcance();
	ret.Mr_qe = this->edtData.Elev_tiro;

	// retornando valor de elevacao para anterior
	this->edtData.Elev_tiro = elevacao_;
	this->voarCompleto();

	// respondendo funcao
	this->rangeMax = ret.Max_rge;
	return ret;
}

void novaEdt::calcularVentoTH(void) {
	
	double start[2] = {0,0};
    double xmin[2];
    double ynewlo;
    double reqmin  = 1e-1;
    double step[2] = {10,10};
    double konvge  = 5;
    double kcount  = 100;
    int   icount;
    int   numres;
    int   ifault;
    int   n = 2;

    nelmin(f_custo_ventoth,this,n,start,xmin,&ynewlo,reqmin,step,konvge,kcount,&icount,&numres,&ifault);

	this->Vweth = this->edtData.Vweth;
	this->Vwnth = this->edtData.Vwnth;
}

void novaEdt::calcularVentoFF(void) {
	
	double start[2] = {0,0};
    double xmin[2];
    double ynewlo;
    double reqmin  = 1e-1;
    double step[2] = {10,10};
    double konvge  = 5;
    double kcount  = 150;
    int   icount;
    int   numres;
    int   ifault;
    int   n = 2;

    nelmin(f_custo_ventoff,this,n,start,xmin,&ynewlo,reqmin,step,konvge,kcount,&icount,&numres,&ifault);

	printf("xmin[0]: %f\n", xmin[0]);
	printf("xmin[1]: %f\n", xmin[1]);
	this->Vweff = this->edtData.Vweff;
	this->Vwnff = this->edtData.Vwnff;
}

struct TShot novaEdt::voarCompleto(void) {
	struct TShot shot;
	condicaoInicial inicio;
	inicio.extrapolar = 0;
	shot = this->voar(&inicio, this->tempoFimSimulacao);
	return shot;
}

struct TShot novaEdt::voarCompleto(double tempoFinal) {
	struct TShot shot;
	condicaoInicial inicio;
	inicio.extrapolar = 0;
	shot = this->voar(&inicio, tempoFinal);
	return shot;
}

struct TShot novaEdt::voarExtrapolando(condicaoInicial *inicio) {
	struct TShot shot;
	print_debug("\n",false);
	print_debug("voarExtrapolando\n\n",true);
	shot = this->voar(inicio, this->tempoFimSimulacao);
	return shot;
}

struct TShot novaEdt::voar(condicaoInicial *inicio, double tempoFinal) {

	struct TShot shot;
	struct StatusStep ststep;
	int erro;

	// inicializando valores de `shot`
	memset(&shot, 0, sizeof(shot));
	memset(&ststep, 0, sizeof(ststep));
	
	double impactoEN[3];
	this->inicializar(inicio);
	double stopHeight = this->edtData.Altarg - this->edtData.Alt_launch;

	// condicao de final de voo
	double apogeu_ = this->stState.ZN;
	double range_apogeu_ = 0;
	
	while (this->T < tempoFinal) {
		
		// calculando passo de simulacao
		ststep = this->step();

		// atualizando valores de ejecao, se houver
		if (ststep.flagEjec) {
			shot.flagEjec = ststep.flagEjec;
			shot.tejec    = ststep.tejec;
			shot.hejec    = ststep.hejec;
		}

		// atualizando apogeu_
		if (this->stState.ZN > apogeu_) {
			apogeu_ = this->stState.ZN;
			range_apogeu_ = sqrt(this->stState.XN*this->stState.XN + this->stState.YN*this->stState.YN);
		}

		// condicao de parada
		if ((this->stState.ZN < stopHeight) && (this->stState.VZN < -10)) {
			break;
		}
	}

	// escrevendo valor de apogeu no objeto nedt
	this->apogeu = apogeu_;
	this->range_apogeu = range_apogeu_;

	// salvando ponto de impacto
	this->calcularCoordenadasEN(impactoEN);
	this->posicaoImpacto[0] = impactoEN[0];
	this->posicaoImpacto[1] = impactoEN[1];
	this->posicaoImpacto[2] = impactoEN[2];

	// retornando valor de Fusetime para os casos de ja ser informado
	if (this->edtData.Fusetime_input > 0.01 && this->edtData.Fusetime_input < 1.e38-1 )
    	this->Fusetime = this->edtData.Fusetime_input;

	// atualizando tempos para foguetes sem espoleta
	if (this->Fusetime == 0 && this->edtData.Sec_bal == 0)
		this->Fusetime = this->T;

	// tratamento dos ERROS
	erro = 0;

	//ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DO ALVO
	if (this->edtData.Alt_launch + apogeu_ < this->edtData.Altarg)
		erro = BALISTIC_ERROR001;

	//ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DE EJECAO
	if (this->Fusetime == 0 && this->edtData.Sec_bal != 0 && erro == 0)
		erro = BALISTIC_ERROR002;

	// retornando TShot
	shot.Az     = this->edtData.Azim_tiro;
	shot.El     = this->edtData.Elev_tiro;
	shot.Fuse   = this->Fusetime;
	shot.Range  = this->calcularAlcance();
	shot.Tf     = this->T;
	shot.Apogee = apogeu_;
	shot.Error  = erro;
	

	return shot;
}

void novaEdt::calcularCoordenadasEN( double *EN ) {
	double ang, m2r = 3.14159265358979 / 180 * 0.05625; // m2r = 1 / 1018.5916;

	double distanciaFrontal = this->stState.YN;
	double distanciaLateral = this->stState.XN;

	ang = this->edtData.Azim_tiro * m2r;

	EN[0] = distanciaLateral * cos(ang) + distanciaFrontal * sin(ang) + this->edtData.Elau;
	EN[1] = distanciaFrontal * cos(ang) - distanciaLateral * sin(ang) + this->edtData.Nlau;
	EN[2] = this->stState.ZN;
}

double novaEdt::calcularDesvioAlcance( void ) {
	double distanciaAlvo[3], distanciaImpacto[3], ret;
	double posicaoLancadora[3]  = { this->edtData.Elau, this->edtData.Nlau, 0 };
	double posicaoAlvo[3] = { this->edtData.Etarg, this->edtData.Ntarg, 0 };

	distanciaAlvo[0] = posicaoAlvo[0] - posicaoLancadora[0];
	distanciaAlvo[1] = posicaoAlvo[1] - posicaoLancadora[1];
	distanciaAlvo[2] = 0;
	distanciaImpacto[0] = this->posicaoImpacto[0] - posicaoLancadora[0];
	distanciaImpacto[1] = this->posicaoImpacto[1] - posicaoLancadora[1];
	distanciaImpacto[2] = 0;

	ret = bradock::produtoEscalar(distanciaAlvo, distanciaImpacto)
			/ bradock::norma(distanciaAlvo) - bradock::norma(distanciaAlvo);
	return ret;
}

double novaEdt::calcularDesvioLateral(void) {
	double distanciaAlvo[3], distanciaImpacto[3], ret;

	double posicaoLancadora[3] = { this->edtData.Elau, this->edtData.Nlau };
	double posicaoAlvo[3] = { this->edtData.Etarg, this->edtData.Ntarg };

	distanciaAlvo[0] = posicaoAlvo[0] - posicaoLancadora[0];
	distanciaAlvo[1] = posicaoAlvo[1] - posicaoLancadora[1];
	distanciaAlvo[2] = 0;
	distanciaImpacto[0] = this->posicaoImpacto[0] - posicaoLancadora[0];
	distanciaImpacto[1] = this->posicaoImpacto[1] - posicaoLancadora[1];
	distanciaImpacto[2] = 0;

	ret = bradock::produtoVetorial(distanciaImpacto, distanciaAlvo, 3)
			/ bradock::norma(distanciaAlvo);
	return ret;
}

double novaEdt::calcularAlcance(void) {
	double distanciaImpacto[3], ret;
	double posicaoLancadora[3] = { this->edtData.Elau, this->edtData.Nlau, 0 };

	distanciaImpacto[0] = this->posicaoImpacto[0] - posicaoLancadora[0];
	distanciaImpacto[1] = this->posicaoImpacto[1] - posicaoLancadora[1];
	distanciaImpacto[2] = 0;

	ret = bradock::norma(distanciaImpacto);
	return ret;
}

void novaEdt::inicializar(condicaoInicial *inicio) {
	//CARREGA A ESTRUTURA PARA TRANSPORTAR
	enum AV_RESULT ret; // RETORNO DE VARIAVEL (AV_OK // AV_FAIL)
	unsigned long crc; // CRC PARA CONFERIR TRANSFERENCIA DE DADOS PARA A FUNCAO

	this->T = (inicio->extrapolar == 0) ? 0 : inicio->tempo;

	// ZERANDO VALORES NO ESPACO DE MEMORIA
	memset(&this->bdt, 0x00, sizeof(AV_BDT));

	//CARREGA A ESTRUTURA PARA TRANSPORTAR
	this->bdt.LENGTH = sizeof(struct TDDT) + sizeof(struct TEdtData);
	memcpy(this->bdt.RAW_DATA, &this->DDTDLL, sizeof(struct TDDT)); // copia valores para bdt.RAW_DATA
	memcpy(this->bdt.RAW_DATA + sizeof(struct TDDT), &this->edtData,
			sizeof(struct TEdtData)); // copia valores para bdt.RAW_DATA+sizeof(TDDT)

	crc = this->CRC32(bdt.RAW_DATA,
			sizeof(struct TDDT) + sizeof(struct TEdtData)); // Calculando CRC -> Ciclic Redundance Check
	memcpy(this->bdt.RAW_DATA + sizeof(struct TDDT) + sizeof(struct TEdtData),
			&crc, sizeof(crc)); // Copiando CRC para bdt.RAW_DATA+sizeof(TDDT)+sizeof(TEdtData)

	this->Endianize(this->bdt.RAW_DATA,
			sizeof(struct TDDT) + sizeof(struct TEdtData) + 4); // O AKAMA fez essa bruxaria aqui pra funcionar

	av_init_bdt(&this->bdt, (enum AV_RESULT *) &ret, this->telaEngenharia); // Inicializando funcoes com valores de foguete e lancamento

	memset(&this->stState, 0x00, sizeof(AV_STATE)); // Zerando valores da variavel de estados
	av_init(&this->stState, inicio, (enum AV_RESULT *) &ret); // Iniciando funcao
}

struct TTelaEngenharia novaEdt::resetTelaEngenharia( void ) {
	// Resetando telaEngenharia
	this->telaEngenharia.Delta_x_e_i    = 1.E+38;
	this->telaEngenharia.Delta_y_e_i    = 1.E+38;
	this->telaEngenharia.Delta_z_e_i    = 1.E+38;
	this->telaEngenharia.Delta_vx_e_i   = 1.E+38;
	this->telaEngenharia.Delta_vy_e_i   = 1.E+38;
	this->telaEngenharia.Delta_vz_e_i   = 1.E+38;
	this->telaEngenharia.Cd_fac_e_i     = 1.E+38;
	this->telaEngenharia.Cdsm_fac_e_i   = 1.E+38;
	this->telaEngenharia.Thrust_fac_e_i = 1.E+38;
	this->telaEngenharia.Tubetime_e_i   = 1.E+38;
	this->telaEngenharia.Delta_ejec_e_i = 1.E+38;
	this->telaEngenharia.Mass_e_i       = 1.E+38;
	this->telaEngenharia.Propmass_e_i   = 1.E+38;
	this->telaEngenharia.Hejec_e_i      = 1.E+38;
	return this->telaEngenharia;
}

void novaEdt::setTelaEngenharia( struct TTelaEngenharia telaEngenharia ) {
	// Inicializando telaEngenharia
	this->telaEngenharia.Delta_x_e_i    = telaEngenharia.Delta_x_e_i;
	this->telaEngenharia.Delta_y_e_i    = telaEngenharia.Delta_y_e_i;
	this->telaEngenharia.Delta_z_e_i    = telaEngenharia.Delta_z_e_i;
	this->telaEngenharia.Delta_vx_e_i   = telaEngenharia.Delta_vx_e_i;
	this->telaEngenharia.Delta_vy_e_i   = telaEngenharia.Delta_vy_e_i;
	this->telaEngenharia.Delta_vz_e_i   = telaEngenharia.Delta_vz_e_i;
	this->telaEngenharia.Cd_fac_e_i     = telaEngenharia.Cd_fac_e_i;
	this->telaEngenharia.Cdsm_fac_e_i   = telaEngenharia.Cdsm_fac_e_i;
	this->telaEngenharia.Thrust_fac_e_i = telaEngenharia.Thrust_fac_e_i;
	this->telaEngenharia.Tubetime_e_i   = telaEngenharia.Tubetime_e_i;
	this->telaEngenharia.Delta_ejec_e_i = telaEngenharia.Delta_ejec_e_i;
	this->telaEngenharia.Mass_e_i       = telaEngenharia.Mass_e_i;
	this->telaEngenharia.Propmass_e_i   = telaEngenharia.Propmass_e_i;
	this->telaEngenharia.Hejec_e_i      = telaEngenharia.Hejec_e_i;
}

/* FIM METODOS DANIEL */

/* METODOS DERSO */

void novaEdt::calcularMediaImpacto(double Norte_Pilotos[100],
		double Leste_Pilotos[100], double Altitude_Pilotos[100],
		int Pontos_Validos[100], int tam, double *Media_Pto_Imp) {
	//////////////////////////////////////////////////////////////////////////////////
	// As entradas do m�todo "media_impacto" s�o:
	// Norte_Pilotos[100]: Um vetor com at� 100 posi��es contendo as coordenadas Norte, em metros, em quadr�cola;
	// Leste_Pilotos[100]: Um vetor com at� 100 posi��es contendo as coordenadas Leste, em metros, em quadr�cola;
	// Altitude_Pilotos[100]: Um vetor com at� 100 posi��es contendo as coordenadas de Altitude, em metros;
	// Pontos_Validos[100]:Um vetor com at� 100 posi��es contendo 1 [pontos v�lidos] e 0 [pontos n�o v�lidos];
	// tam: Tamanho do vetor de posi��es, ou seja, quantidade de foguetes pilotos que foram lan�ados;
	// Media_Pto_Imp[3]: M�dia dos Impactos dos Pontos V�lidos em metros [0] Leste, [1] Norte e [2] Altitude;
	/////////////////////////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////////////////
	// Vari�veis internas do m�todo:
	//
	/////////////////////////////////////////////////////////////////////////////////
	double Soma_Leste = 0;	//[m]
	double Soma_Norte = 0;	//[m]
	double Soma_H = 0;
	int contador = 0;	//
	///////////////////////////////////////////////////////////////////////////////////
	// Essa for � para percorrer o vetor at� o tamanho que o us�rio do m�todo informou
	// que haver� dados preenchidos.
	//
	///////////////////////////////////////////////////////////////////////////////////

	for (int var = 0; var < tam; ++var) {
		//////////////////////////////////////////////////////////////////////////////////
		// Caso o ponto seja uma coordenada v�lida, ent�o ele ir� entrar na computa��o da
		// m�dia do ponto de impacto. Caso contra�rio o programa n�o faz nada.
		//
		/////////////////////////////////////////////////////////////////////////////////
		if (Pontos_Validos[var] == 1) {
			Soma_Leste = Soma_Leste + Leste_Pilotos[var];
			Soma_Norte = Soma_Norte + Norte_Pilotos[var];
			Soma_H = Soma_H + Altitude_Pilotos[var];
			contador++;
		} else {
			//////////////////////////////////////////////////////////////////////////////////
			// Ta vendo???!!! N�o acontece nada no else!!!
			//
			///////////////////////////////////////////////////////////////////////////////////
		}; // (Pontos_Validos==1)

	}; // for (int var = 0; var < tam; ++var)

	//////////////////////////////////////////////////////////////////////////////////
	// Aqui � um truque para quando nenhum ponto for v�lido isso evita uma divis�o por
	// zero.
	//
	/////////////////////////////////////////////////////////////////////////////////

	if (contador == 0)
		contador = 1;

	////////////////////////////////////////////////////////////////////////////////
	//			Aqui � feito o c�lculo da m�dia dos pontos de Impacto
	//
	////////////////////////////////////////////////////////////////////////////////

	Media_Pto_Imp[0] = Soma_Leste / contador;
	Media_Pto_Imp[1] = Soma_Norte / contador;
	Media_Pto_Imp[2] = Soma_H / contador;
}

void novaEdt::tratarDadosRadar(double Tfq, double *Fim_de_queima,
		double *Pto_extrap, int *Erro) {

	int num_de_pto = 0;	//n�mero de pontos da trajet�ria.
	char Lock_On[15] = "Lock_On";
	char Measured[15] = "Measured_Data";
	int lock = 0;	//onde come�ou a pergar
	int erro[5] = { 0, 0, 0, 0, 0 };
	////////////////////////////////////////////////////////////////////////////////////////////
	//erro[0]=1 (O arquivo n�o tem pontos)
	//erro[1]=1 (O arquivo tem pontos, mas n�o tem Lock_on
	//erro[2]=1 (O arquivo n�o tem um ponto medido de tempo de queima)
	//erro[3]=1 (N�o existem pontos suficientes para determinar uma boa extrapola��o)
	//erro[4] (reservado)
	///////////////////////////////////////////////////////////////////////////////////////////
	int cont_tq = 0;
	int inicial;
	int final = 0;
	int init_extrap;
	int aux = 0;
	int indice = 0;
	double valor = 0.0;

	////////////////////////////////////////////////////////////////////////////////
	//		Anteriormente eu fazia um malabarismo para pergar esses dados
	//
	//	Agora eu estou pegando esse n�mero pronto que o radar me envia.
	//
	////////////////////////////////////////////////////////////////////////////////

	num_de_pto = this->CntTrkData;

	if (num_de_pto == 0)
		erro[0] = 1; //O arquivo n�o tem pontos

	////////////////////////////////////////////////////////////////////////////////
	//						Procurando o Lock_on
	//
	//Onde o arquivo realmente inicia � quando encontramos o Lock_on. Dito de outra
	//forma, se n�o h� Lock_on n�o h� rastreio.
	////////////////////////////////////////////////////////////////////////////////

	while ((strcmp(this->TrackingData.MissionState[lock], Lock_On))
			&& (lock <= num_de_pto))
		lock++;

	////////////////////////////////////////////////////////////////////////////////

	if (lock >= num_de_pto) {
		erro[1] = 1; // O arquivo tem pontos, mas n�o tem Lock_on
		cont_tq = 30; // Inventei um ponto para o programa n�o parar.
	} else {
		cont_tq = lock; // O contador come�a do Lock_on
	}

	////////////////////////////////////////////////////////////////////////////////
	//							Procurando fim da queima
	//
	//
	////////////////////////////////////////////////////////////////////////////////

	while ((this->TrackingData.RelativeTime[cont_tq] < (int) (Tfq * 1000))
			&& (cont_tq <= num_de_pto)) {
		//////////////////////////////////////////////////////////////////////////////
		//Aqui ele incrementa o contador a primeira vez. Em seguida ele verifica se
		//o dado em quest�o � um dado medido "Measured_Data". Se for, ele j� sai fora
		//desse loop. Caso contr�rio ele continua incrementando o contador at� encontrar
		//um dado medido.
		//
		/////////////////////////////////////////////////////////////////////////////
		do {
			cont_tq++;
		} while (strcmp(this->TrackingData.MeasuredPositionState[cont_tq],
				Measured) && (cont_tq <= num_de_pto));
	}

	////////////////////////////////////////////////////////////////////////////////

	if (cont_tq >= num_de_pto) {
		erro[2] = 1;	//O arquivo n�o tem um ponto medido de tempo de queima
		cont_tq = 350;		//Inventei um para o programa n�o parar
	};

	///////////////////////////////////////////////////////////////////////////////
	//				Aqui colocamos o ponto do final da queima.
	//
	//
	//////////////////////////////////////////////////////////////////////////////
	Fim_de_queima[0] = this->TrackingData.RelativeTime[cont_tq] / 1000.0;
	Fim_de_queima[1] = this->TrackingData.FilteredPositionX[cont_tq];
	Fim_de_queima[2] = this->TrackingData.FilteredPositionY[cont_tq];
	Fim_de_queima[3] = this->TrackingData.FilteredPositionZ[cont_tq];
	Fim_de_queima[4] = this->TrackingData.FilteredVelocityX[cont_tq];
	Fim_de_queima[5] = this->TrackingData.FilteredVelocityY[cont_tq];
	Fim_de_queima[6] = this->TrackingData.FilteredVelocityZ[cont_tq];

	//////////////////////////////////////////////////////////////////////////////
	//Fiquei pensando durante muito tempo na quantidade de dados que deveriamos ter
	//para verificar o melhor ponto para a o inicio da extrapola��o.
	//Como a taxa de dados do arquivo � 50 Hz, uma boa quantidade de pontos para
	//para iniciar a busca de um melhor ponto para a extrapola��o seriam 5 segundos (250 ptos).
	//Contudo, n�o estamos imaginando qualquer 5 segundos estamos imaginando 5 segundos
	//de pontos medidos.
	//Fiz alguns testes e cheguei a conclus�o que esses 250 ptos � uma boa quantidade.
	/////////////////////////////////////////////////////////////////////////////
	aux = num_de_pto;
	/////////////////////////////////////////////////////////////////////////////
	//Esse trecho do c�digo ainda est� sob judice. Vamos imaginar que voc� est� com
	//rastreando um foguete qualquer. A pergunta �: Quantos segundos iremos avaliar
	//para decidir o ponto de extrapola��o?
	//Vamos avaliar os 20% segundos finais. � isso que essa conta abaixo faz.
	/////////////////////////////////////////////////////////////////////////////
	int tam_ini;
	tam_ini = (int) num_de_pto * 0.2;

	do {
		if (strcmp(this->TrackingData.MeasuredPositionState[aux], Measured)
				== 0)
			final++;
		aux--;
	} while ((final < tam_ini) && (aux != 0));

	/////////////////////////////////////////////////////////////////////////////

	inicial = aux;

	if (inicial < tam_ini)
		erro[3] = 1; //N�o existem pontos suficientes para determinar uma boa extrapola��o.

	for (int var = (inicial); var < num_de_pto; ++var) {
		valor = this->TrackingData.OneSigmaX[var] + this->TrackingData.OneSigmaY[var] + this->TrackingData.OneSigmaZ[var];
		
		if (this->TrackingData.OneSigmaX[var] == 0) {
			/////////////////////////////////////////////////////////////////////////////////
			//Sabemos que quando existe um ponto vindo de um valor simulado o valor do sigma
			//para esse ponto � zero. Isso significa que na hora de buscar o ponto m�nimo
			//estariamos colocando encontrando um m�nimo falso. Da�, para esses pontos,
			//estou colocando um valor bem grande.
			////////////////////////////////////////////////////////////////////////////////
			valor = 3000.0;
		}

		////////////////////////////////////////////////////////////////////////////////
		//		Criei um vetor que eu estou preenchendo com a soma dos 3 sigmas.
		//
		///////////////////////////////////////////////////////////////////////////////
		this->Sigma_V[indice] = valor;
		indice++;
	}

	//////////////////////////////////////////////////////////////////////////////
	//Dai, ent�o, procuro nesse vetor o ponto m�nimo. E, a partir desse ponto
	//m�nimo a extrapola��o ir� iniciar.
	//
	//////////////////////////////////////////////////////////////////////////////
	init_extrap = bradock::minimo(this->Sigma_V, num_de_pto - inicial);

	/////////////////////////////////////////////////////////////////////////////
	init_extrap = inicial + init_extrap;//ponto onde deve iniciar a extrapola��o.

	/////////////////////////////////////////////////////////////////////////////
	Pto_extrap[0] = this->TrackingData.RelativeTime[init_extrap] / 1000.0;
	Pto_extrap[1] = this->TrackingData.FilteredPositionX[init_extrap];
	Pto_extrap[2] = this->TrackingData.FilteredPositionY[init_extrap];
	Pto_extrap[3] = this->TrackingData.FilteredPositionZ[init_extrap];
	Pto_extrap[4] = this->TrackingData.FilteredVelocityX[init_extrap];
	Pto_extrap[5] = this->TrackingData.FilteredVelocityY[init_extrap];
	Pto_extrap[6] = this->TrackingData.FilteredVelocityZ[init_extrap];

	Erro[0] = erro[0];
	Erro[1] = erro[1];
	Erro[2] = erro[2];
	Erro[3] = erro[3];
	Erro[4] = erro[4];
}

/* FIM METODOS DERSO */

/* FUNCOES BASICAS */

struct StatusStep novaEdt::step() {
	double Fuse_o;
	double Hejec_o;
	struct StatusStep ststep = {0, 0.0, 0.0};

	// calculando passo de simulacao
	av_step(&this->stState, &this->ret, &Fuse_o, &Hejec_o, &ststep);

	this->Fusetime = Fuse_o;
	this->Hejec = Hejec_o;

	// atualizando estados do voo
	this->stState.XO = this->stState.XN;
	this->stState.YO = this->stState.YN;
	this->stState.ZO = this->stState.ZN;
	this->stState.VXO = this->stState.VXN;
	this->stState.VYO = this->stState.VYN;
	this->stState.VZO = this->stState.VZN;
	this->stState.ZO_SPH = this->stState.ZN_SPH;

	// atualizando tempo de simulacao
	this->T = retornaTempo();

	return ststep;
}

void novaEdt::Endianize(char *buf, int buflen) {
	// Metodo para ajustar littleenian bigendian
	int i;
	unsigned long *p;

	p = (unsigned long *) buf;
	for (i = 0; i < (buflen / 4); i++)
		p[i] = LongSwap(p[i]);
}

void novaEdt::init_crc32_tab(void) {
	int i, j;
	unsigned long crc;

	crc_tab32_init = FALSE;
	for (i = 0; i < 256; i++) {
		crc = (unsigned long) i;
		for (j = 0; j < 8; j++) {
			if (crc & 0x00000001L)
				crc = (crc >> 1) ^ P_32;
			else
				crc = crc >> 1;
		}
		crc_tab32[i] = crc;
	}
	crc_tab32_init = TRUE;
}

unsigned long novaEdt::update_crc_32(unsigned long crc, char c) {
	unsigned long tmp, long_c;

	long_c = 0x000000ffL & (unsigned long) c;
	if (!this->crc_tab32_init)
		this->init_crc32_tab();
	tmp = crc ^ long_c;
	crc = (crc >> 8) ^ this->crc_tab32[tmp & 0xff];
	return crc;
}

unsigned long novaEdt::CRC32(char *buf, int buflen) {
	int i;
	unsigned long ret = 0;

	for (i = 0; i < buflen; i++)
		ret = this->update_crc_32(ret, buf[i]);

	return ret;
}

struct TDDT novaEdt::SetDataDDT(int DDTType) {
	// Metodo para inicializar o arquivo ddt
	struct TDDT DDT;
	switch (DDTType) {
		case SS_09TS:
			#if defined(C2001)
				#include "../BDT/BDT09_200.C"
			#else
				#include "../BDT/BDT09.C"
			#endif
			break;
		case SS_30:
			#include "../BDT/BDT30.C"
			break;
		case SS_40:
			#include "../BDT/BDT40.C"
			break;
		case SS_60:
			#include "../BDT/BDT60.C"
			break;
		case SS_80:
			#include "../BDT/BDT80.C"
			break;    
		case SS_40G:
			#include "../BDT/BDT40G.C"
			break;
	}
	return (DDT);
}

/* FIM FUNCOES BASICAS */

/* FUNCOES FLAVIO */

char * novaEdt::Rocket(int DDTType) {

	static char RocketName[25];
	strcpy(RocketName,"UNKNOWN");

	switch (DDTType) {
		case SS_09TS:
			strcpy(RocketName,"SS_09TS");
			break;
		case SS_30:
			strcpy(RocketName,"SS_30");
			break;
		case SS_40:
			strcpy(RocketName,"SS_40");
			break;
		case SS_60:
			strcpy(RocketName,"SS_60");
			break;
		case SS_80:
			strcpy(RocketName,"SS_80");
			break;
		case SS_40G:
			strcpy(RocketName,"SS_40G");
			break;
	}
	return (RocketName);
}

// Metodo para inicializar o arquivo edtData
void novaEdt::SetData(struct TEdtData loadData) {
	this->edtData = loadData;

	char txt[LOG_SIZE];
	print_debug("SetData sucessfully done.\n",false);

	print_debug_edtdata(CurrentTime());
	print_debug_edtdata("[start] ------------------------------------------------------------------\n");
	sprintf(txt,"\t edtData.DDTType=%d\n"
				"\t edtData.Latitude=%.2f\n"
				"\t edtData.Sec_bal=%d\n"
				"\t edtData.Metcm_included=%d\n"
				"\t edtData.Natm=%d\n"
				,this->edtData.DDTType,this->edtData.Latitude,this->edtData.Sec_bal,this->edtData.Metcm_included,this->edtData.Natm);
	print_debug_edtdata(txt);
	for (int i = 0; i < 41; i++)
	{
		sprintf(txt,"\t edtData.Vwmetcm[%d]=%.2f\n"
					"\t edtData.Azwmetcm[%d]=%.2f\n"
					"\t edtData.Tent[%d]=%.2f\n"
					"\t edtData.Pent[%d]=%.2f\n"
					,i,this->edtData.Vwmetcm[i],i,this->edtData.Azwmetcm[i],i,this->edtData.Tent[i],i,this->edtData.Pent[i]);
		print_debug_edtdata(txt);
	}
	sprintf(txt,"\t edtData.Alt_met=%.2f\n"
				"\t edtData.Azwcor=%.2f\n"
				"\t edtData.T0=%.2f\n"
				"\t edtData.P0=%.2f\n"
				"\t edtData.Proptemp=%.2f\n"
				"\t edtData.Vws=%.2f\n"
				"\t edtData.Azws=%.2f\n"
				"\t edtData.Altfg=%.2f\n"
				"\t edtData.RefDir=%.2f\n"
				"\t edtData.Elau=%.2f\n"
				"\t edtData.Nlau=%.2f\n"
				"\t edtData.Alt_launch=%.2f\n"
				"\t edtData.Etarg=%.2f\n"
				"\t edtData.Ntarg=%.2f\n"
				"\t edtData.Altarg=%.2f\n"
				"\t edtData.Azim_tiro=%.2f\n"
				"\t edtData.Elev_tiro=%.2f\n"
				"\t edtData.Fusetime_input=%.2f\n"
				"\t edtData.Vweth=%.2f\n"
				"\t edtData.Vwnth=%.2f\n"
				"\t edtData.Vweff=%.2f\n"
				"\t edtData.Vwnff=%.2f\n"
				"\t edtData.Elev_max=%.2f\n"
				"\t edtData.CalType=%d\n"
				,this->edtData.Alt_met,this->edtData.Azwcor,this->edtData.T0,this->edtData.P0,this->edtData.Proptemp,this->edtData.Vws,this->edtData.Azws
				,this->edtData.Altfg,this->edtData.RefDir,this->edtData.Elau,this->edtData.Nlau,this->edtData.Alt_launch,this->edtData.Etarg,this->edtData.Ntarg,this->edtData.Altarg,this->edtData.Azim_tiro,this->edtData.Elev_tiro
				,this->edtData.Fusetime_input,this->edtData.Vweth,this->edtData.Vwnth,this->edtData.Vweff,this->edtData.Vwnff,this->edtData.Elev_max,this->edtData.CalType);
	print_debug_edtdata(txt);
	print_debug_edtdata(CurrentTime());
	print_debug_edtdata("[end] --------------------------------------------------------------------\n");
}

void novaEdt::SetDebug(bool Type) {
	char txt[LOG_SIZE];

	sprintf(txt, "Setting Debug: Type = %s\n", Type ? "true" : "false");
	print_debug(txt,false);

	bDebug = Type;

	sprintf(txt, "SetDebug: bDebug = %s\n", bDebug ? "true" : "false");
	print_debug(txt,false);
}

bool novaEdt::GetDebug(void) {
	char txt[LOG_SIZE];
	sprintf(txt, "GetDebug : bDebug = %s\n", bDebug ? "true" : "false");
	print_debug(txt,false);

	return bDebug;
}

void novaEdt::SetCntTrkData(int nValue) {
	CntTrkData = nValue;

	char txt[LOG_SIZE];
	sprintf(txt, "SetCntTrkData: CntTrkData = %d\n", CntTrkData);
	print_debug(txt,false);
}

void novaEdt::SetExtrapolationStart(unsigned Value) {
	ExtrapolationStart = Value;

	char txt[LOG_SIZE];
	sprintf(txt, "SetExtrapolationStart: ExtrapolationStart = %d\n",
			ExtrapolationStart);
	print_debug(txt,false);
}

void novaEdt::SetEdtDataReceived(bool bValue) {
	bEdtDataReceived = bValue;

	char txt[LOG_SIZE];
	sprintf(txt, "SetEdtDataReceived: bEdtDataReceived = %s\n",
			bEdtDataReceived ? "true" : "false");
	print_debug(txt,false);
}

bool novaEdt::GetEdtDataReceived(void) {
	char txt[LOG_SIZE];
	sprintf(txt, "GetEdtDataReceived: bEdtDataReceived = %s\n",
			bEdtDataReceived ? "true" : "false");
	print_debug(txt,false);

	return bEdtDataReceived;
}

void novaEdt::SetTrackingDataReceived(bool bValue) {
	bTrackingDataReceived = bValue;

	char txt[LOG_SIZE];
	sprintf(txt, "SetTrackingDataReceived: bTrackingDataReceived = %s\n",
			bTrackingDataReceived ? "true" : "false");
	print_debug(txt,false);
}

bool novaEdt::GetTrackingDataReceived(void) {
	char txt[LOG_SIZE];
	sprintf(txt,
			"GetTrackingDataReceived: bTrackingDataReceived = %s\n",
			bTrackingDataReceived ? "true" : "false");
	print_debug(txt,false);

	return bTrackingDataReceived;
}

void novaEdt::SetTrackingData(struct TTrackingResult * TrkData) {
	char txt[LOG_SIZE];
	sprintf(txt, "SetTrackingData started: CntTrkData = %d\n", CntTrkData);
	print_debug(txt,false);

	print_debug_trkdata(CurrentTime());
	print_debug_trkdata("[start] ------------------------------------------------------------------\n");

	for (int i = 0; i < this->CntTrkData; i++)
	{
		for (int j = 0; j < 18; j++)
		{
			TrackingData.MissionState[i][j] = TrkData->MissionState[i][j];
		}
		for (int j = 0; j < 15; j++)
		{
			TrackingData.MeasuredPositionState[i][j] = TrkData->MeasuredPositionState[i][j];
		}
		TrackingData.MeasuredPositionX[i] = TrkData->MeasuredPositionX[i];
		TrackingData.MeasuredPositionY[i] = TrkData->MeasuredPositionY[i];
		TrackingData.MeasuredPositionZ[i] = TrkData->MeasuredPositionZ[i];
		TrackingData.OneSigmaX[i] = TrkData->OneSigmaX[i];
		TrackingData.OneSigmaY[i] = TrkData->OneSigmaY[i];
		TrackingData.OneSigmaZ[i] = TrkData->OneSigmaZ[i];
		TrackingData.SignalToNoiseRatio[i] = TrkData->SignalToNoiseRatio[i];
		TrackingData.FilteredPositionX[i] = TrkData->FilteredPositionX[i];
		TrackingData.FilteredPositionY[i] = TrkData->FilteredPositionY[i];
		TrackingData.FilteredPositionZ[i] = TrkData->FilteredPositionZ[i];
		TrackingData.FilteredVelocityX[i] = TrkData->FilteredVelocityX[i];
		TrackingData.FilteredVelocityY[i] = TrkData->FilteredVelocityY[i];
		TrackingData.FilteredVelocityZ[i] = TrkData->FilteredVelocityZ[i];
		TrackingData.RelativeTime[i] = TrkData->RelativeTime[i];

		//Printing log file
		print_debug_trkdata(TrackingData.MissionState[i]);
		print_debug_trkdata("\t");
		print_debug_trkdata(TrackingData.MeasuredPositionState[i]);
		sprintf(txt,"\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %.2f\t %d\n"
				,TrackingData.MeasuredPositionX[i]
				,TrackingData.MeasuredPositionY[i]
				,TrackingData.MeasuredPositionZ[i]
				,TrackingData.OneSigmaX[i]
				,TrackingData.OneSigmaY[i]
				,TrackingData.OneSigmaZ[i]
				,TrackingData.SignalToNoiseRatio[i]
				,TrackingData.FilteredPositionX[i]
				,TrackingData.FilteredPositionY[i]
				,TrackingData.FilteredPositionZ[i]
				,TrackingData.FilteredVelocityX[i]
				,TrackingData.FilteredVelocityY[i]
				,TrackingData.FilteredVelocityZ[i]
				,TrackingData.RelativeTime[i]);
		print_debug_trkdata(txt);
	}

	print_debug_trkdata(CurrentTime());
	print_debug_trkdata("[end] --------------------------------------------------------------------\n");
}

struct TTrackingResult * novaEdt::GetTrackingData(void) {
	print_debug("GetTrackingData\n",false);
	return &TrackingData;
}

void novaEdt::ConfiguraNEDT(void) {
	print_debug("ConfiguraNEDT\n",false);
//void ConfiguraNEDT(novaEdt *nedt, struct RADAR *derso, double *Lanc, double *ponteiroTabelaVento){
	double C0_fq[7], C0_extrap[7];
	int erro[5];
	char txt[LOG_SIZE];

	//double Tabela_Vento[41][5];
	//memcpy(&Tabela_Vento,ponteiroTabelaVento,sizeof(Tabela_Vento));

	tratarDadosRadar(tempoQueima, C0_fq, C0_extrap, erro);

	// CONDICAO INICIAL EXTRAP
	condicaoInicial inicio;
	inicio.extrapolar = TRUE;

	// DADOS DO RADAR
	inicio.tempo  = C0_extrap[0];
	inicio.pos[0] = C0_extrap[1];
	inicio.pos[1] = C0_extrap[2];
	inicio.pos[2] = C0_extrap[3];
	inicio.vel[0] = C0_extrap[4];
	inicio.vel[1] = C0_extrap[5];
	inicio.vel[2] = C0_extrap[6];

	voarExtrapolando(&inicio);

	double Imp[3];
	calcularCoordenadasEN(Imp);

	sprintf(txt, "\t\t"
			"Final da Queima \n\n"
			"Tempo de inicio = %7.2lf\n"
			"Coordenada X    = %7.2lf\n"
			"Coordenada Y    = %7.2lf\n"
			"Coordenada Z    = %7.2lf\n"
			"Velocidade X    = %7.2lf\n"
			"Velocidade Y    = %7.2lf\n"
			"Velocidade Z    = %7.2lf\n", C0_fq[0], C0_fq[1], C0_fq[2],
			C0_fq[3], C0_fq[4], C0_fq[5], C0_fq[6]);
	printf("\n");
	print_debug(txt,false);

	posicaoFimDeQueima[0] = C0_fq[1];
	posicaoFimDeQueima[1] = C0_fq[2];
	posicaoFimDeQueima[2] = C0_fq[3];
	velocidadeFimDeQueima[0] = C0_fq[4];
	velocidadeFimDeQueima[1] = C0_fq[5];
	velocidadeFimDeQueima[2] = C0_fq[6];

	posicaoFimDeVoo[0] = Imp[0];
	posicaoFimDeVoo[1] = Imp[1];
	posicaoFimDeVoo[2] = Imp[2];
}

// Metodo para imprimir resumo dos dados do voo
void novaEdt::ImprimeResumoDadosVoo(void) {
	FILE *debug_file;
	char file[MAX_PATH];
	char txt[LOG_SIZE];
	double C0_fq[6], C0_extrap[6];
	int erro[5];
	int i;

	tratarDadosRadar((tempoQueima*2),C0_fq,C0_extrap,erro);

	strcpy(file, strOutDir);
	strcat(file, CurrentDate());
	strcat(file, "_HBCT_Resumo_Dados_Voo.txt");
	debug_file = fopen(file, "a+");

	fprintf(debug_file, "\n\n----------------------------------------------------------------------------------------\n");
	fprintf(debug_file, "** RESUMO DOS DADOS DE VOO - ASTROS MK6 **\n\n");
	strcpy(txt, "DATA: ");
	strcat(txt, CurrentTimePrint());
	strcat(txt, "\n");
	fprintf(debug_file, txt);
	strcpy(txt, "TIPO DE BALISTICA: ");
	strcat(txt, Rocket(edtData.DDTType));
	strcat(txt, "\n");
	fprintf(debug_file, txt);
	sprintf(txt,"TEMPO IDENTIFICADO DE VOO: %.2f\n",C0_extrap[0]);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n= CONDICOES DO TIRO = \n\n");
	sprintf(txt,"Elevacao             = %8.0f (mils) \n",edtData.Elev_tiro);
	fprintf(debug_file, txt);
	sprintf(txt,"Azimute              = %8.0f (mils) \n",edtData.Azim_tiro);
	fprintf(debug_file, txt);
	sprintf(txt,"Alcance              = %8.0f (m) \n",calcularAlcance());
	fprintf(debug_file, txt);
	sprintf(txt,"Balistica secundaria =        %d  \n",edtData.Sec_bal);
	fprintf(debug_file, txt);                              
	//if(this->Fusetime < 0.01) TempoEscolhido = this->T; else TempoEscolhido = this->Fusetime;
	sprintf(txt,"Tempo escolhido      = %8.2f (s) \n",edtData.Fusetime_input);
	fprintf(debug_file, txt);
	sprintf(txt,"Altura da ejecao     = %8.2f (m) \n",this->Hejec);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n= COORDENADAS DO LANCADOR = \n\n");
	sprintf(txt,"Este                 = %8.0f (m) \n",edtData.Elau);
	fprintf(debug_file, txt);
	sprintf(txt,"Norte                = %8.0f (m) \n",edtData.Nlau);
	fprintf(debug_file, txt);
	sprintf(txt,"Altitude             = %8.0f (m) \n",edtData.Alt_launch);
	fprintf(debug_file, txt);
	sprintf(txt,"Latitude             = %8.0f (m) \n",edtData.Latitude);
	fprintf(debug_file, txt);
                                
	fprintf(debug_file,"\n= COORDENADAS DO ALVO = \n\n");
	sprintf(txt,"Este                 = %8.0f (m) \n",edtData.Etarg);
	fprintf(debug_file, txt);
	sprintf(txt,"Norte                = %8.0f (m) \n",edtData.Ntarg);
	fprintf(debug_file, txt);
	sprintf(txt,"Altitude             = %8.0f (m) \n",edtData.Altarg);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n\n= PONTOS DE CONTROLE = \n\n");

	fprintf(debug_file,"\n- COORDENADAS DO PONTO DE EXTRAPOLACAO - \n\n");
	sprintf(txt,"Extrapolacao em x    = %8.2f (m) \n",C0_extrap[1]);
	fprintf(debug_file, txt);
	sprintf(txt,"Extrapolacao em y    = %8.2f (m) \n",C0_extrap[2]);
	fprintf(debug_file, txt);
	sprintf(txt,"Extrapolacao em z    = %8.2f (m) \n",C0_extrap[3]);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n- COORDENADAS APOS FIM DE QUEIMA - \n\n");
	sprintf(txt,"Coordenada em x      = %8.2f (m) \n",C0_fq[1]);
	fprintf(debug_file, txt);
	sprintf(txt,"Coordenada em y      = %8.2f (m) \n",C0_fq[2]);
	fprintf(debug_file, txt);
	sprintf(txt,"Coordenada em z      = %8.2f (m) \n",C0_fq[3]);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n\n= CONDICOES ATMOSFERICAS = \n\n");
                                                   
	fprintf(debug_file,"\n*CONDICOES DE SUPERFICIE*\n\n");
	sprintf(txt,"Temperatura do ar         = %8.2f (celsius) \n",edtData.T0);
	fprintf(debug_file, txt);
	sprintf(txt,"Pressao atmosferica       = %8.2f (mbar) \n",edtData.P0);
	fprintf(debug_file, txt);
	sprintf(txt,"Temperatura do propelente = %8.2f (Kg/m3) \n",edtData.Proptemp);
	fprintf(debug_file, txt);
	sprintf(txt,"Velocidade vento superf.  = %8.2f (knots) \n",edtData.Vws);
	fprintf(debug_file, txt);
	sprintf(txt,"Azimute vento superf.     = %8.2f (mils) \n",edtData.Azws);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n*BOLETIM ATMOSFERICO*\n\n");
	sprintf(txt,"Altitude da estacao meteorologica   = %8.0f (m) \n",edtData.Alt_met);
	fprintf(debug_file, txt);
	sprintf(txt,"Numero da ultima camada entrada     =       %d \n",edtData.Natm);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\nNo. DE   DIRECAO   VELOCIDADE   TEMPERATURA   PRESSAO");
	fprintf(debug_file,"\nCAMADAS  DO VENTO  DO VENTO\n");
	fprintf(debug_file,"\n          (mils)    (Knots)         (k)        (mbar)\n");
	for (i = 0; i <= edtData.Natm; i++)
	{
		sprintf(txt,"   %d\t   %4.0f\t       %3.1f\t   %3.1f\t%4.1f\n",i,edtData.Azwmetcm[i],edtData.Vwmetcm[i],edtData.Tent[i],edtData.Pent[i]);
		fprintf(debug_file, txt);
	}

	
	fprintf(debug_file,"\n\n= RESULTADOS = \n\n");

	fprintf(debug_file,"\n*VENTOS IDENTIFICADOS*\n\n"); 
	fprintf(debug_file,"\n- ESTE E NORTE -\n");
	sprintf(txt,"Vento de fase propulsada: Frontal   = %8.2f (m/s) \n",edtData.Vweth);
	fprintf(debug_file, txt);
	sprintf(txt,"                          Lateral   = %8.2f (m/s) \n",edtData.Vwnth);
	fprintf(debug_file, txt);
	sprintf(txt,"Vento de fase balistica : Frontal   = %8.2f (m/s) \n",edtData.Vweff);
	fprintf(debug_file, txt);
	sprintf(txt,"                          Lateral   = %8.2f (m/s) \n",edtData.Vwnff);
	fprintf(debug_file, txt);
	
	fprintf(debug_file,"\n*COORDENADAS DO PONTO DE IMPACTO*\n\n");
	sprintf(txt,"Este               = %8.0f (m) \n",posicaoFimDeVoo[0]);
	fprintf(debug_file, txt);
	sprintf(txt,"Norte              = %8.0f (m) \n",posicaoFimDeVoo[1]);
	fprintf(debug_file, txt);

	fprintf(debug_file,"\n*APOGEU E DESVIOS*\n\n");
	sprintf(txt,"Apogeu             = %8.0f (m) \n",this->apogeu);
	fprintf(debug_file, txt);
	sprintf(txt,"Desvio em alcance  = %8.0f (m) \n",calcularDesvioAlcance());
	fprintf(debug_file, txt);
	sprintf(txt,"Desvio lateral     = %8.0f (m) \n",calcularDesvioLateral());
	fprintf(debug_file, txt);
	
	fprintf(debug_file,"\n*ERROS ENCONTRADOS*\n\n"); 
	if (erro[0]==1) {
		fprintf(debug_file," erro[0]=1\n          O arquivo n�o tem pontos\n\n");
	}
	if (erro[1]==1) {
		fprintf(debug_file," erro[1]=1\n          O arquivo tem pontos, mas n�o tem Lock_on\n\n");
	}
	if (erro[2]==1) {
		fprintf(debug_file," erro[2]=1\n          O arquivo nao tem ponto medido de tempo de fim de queima\n\n");
	}
	if (erro[3]==1) {
		fprintf(debug_file," erro[3]=1\n          Nao existem pontos suficientes para determinar uma boa extrapolacao\n\n");
	}
	if (erro[4]==1) {
		fprintf(debug_file," erro[4]=1\n          Reservado\n\n");
	}

	
	fprintf(debug_file,"\n\n************  T A B E L A   D E   P O S I C A O   E   V E L O C I D A D E  ******************************************************************************************************************************************************************************************\n\n");

	fprintf(debug_file," DataSet   MissionState	PositionState	Measured Pos X	Measured Pos Y	Measured Pos Z	One Sigma X	One Sigma Y	One Sigma Z	Noise Ratio	Filtered Pos X	Filtered Pos Y	Filtered Pos Z	Filtered Vel X	Filtered Vel Y	Filtered Vel Z	Relative Time\n");
	for (int i = 0; i < this->CntTrkData; i++)
	{
		//Printing log file
		sprintf(txt,"   %d\t   ",i);
		fprintf(debug_file, txt);
		fprintf(debug_file,TrackingData.MissionState[i]);
		fprintf(debug_file,"\t");
		fprintf(debug_file,TrackingData.MeasuredPositionState[i]);
		sprintf(txt,"\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %8.2f\t %d\n"
				,TrackingData.MeasuredPositionX[i]
				,TrackingData.MeasuredPositionY[i]
				,TrackingData.MeasuredPositionZ[i]
				,TrackingData.OneSigmaX[i]
				,TrackingData.OneSigmaY[i]
				,TrackingData.OneSigmaZ[i]
				,TrackingData.SignalToNoiseRatio[i]
				,TrackingData.FilteredPositionX[i]
				,TrackingData.FilteredPositionY[i]
				,TrackingData.FilteredPositionZ[i]
				,TrackingData.FilteredVelocityX[i]
				,TrackingData.FilteredVelocityY[i]
				,TrackingData.FilteredVelocityZ[i]
				,TrackingData.RelativeTime[i]);
		fprintf(debug_file, txt);
	}

	fclose(debug_file);
}

// Metodo para imprimir arquivo de msgs de erro
void novaEdt::print_error(const char * msg) {
	FILE *debug_file;
	char file[MAX_PATH];
	strcpy(file, strOutDir);
	strcat(file, CurrentDate());
	strcat(file, "_HBCT_ERROR.txt");
	debug_file = fopen(file, "a+");
	fprintf(debug_file, msg);
	fclose(debug_file);
}

// Metodo para imprimir arquivo de debug
void novaEdt::print_debug(const char * msg, bool bTime) {
	if (this->bDebug) {
		FILE *debug_file;
		char file[MAX_PATH];
		strcpy(file, strOutDir);
		strcat(file, CurrentDate());
		strcat(file, "_HBCT_Debug.txt");
		debug_file = fopen(file, "a+");
		if (bTime) fprintf(debug_file, CurrentTime());
		fprintf(debug_file, msg);
		fclose(debug_file);
	}
}

// Metodo para imprimir arquivo com edtdata carregado em modo debug
void novaEdt::print_debug_edtdata(const char * msg) {
	if (bDebug) {
		FILE *debug_file;
		char file[MAX_PATH];
		strcpy(file, strOutDir);
		strcat(file, CurrentDate());
		strcat(file, "_HBCT_EdtData.txt");
		debug_file = fopen(file, "a+");
		fprintf(debug_file, msg);
		fclose(debug_file);
	}
}

// Metodo para imprimir arquivo com trakingdata em modo debug
void novaEdt::print_debug_trkdata(const char * msg)
{
	if (bDebug)
	{
		FILE *debug_file;
		char file[MAX_PATH];
		strcpy(file,strOutDir);
		strcat(file,CurrentDate());
		strcat(file,"_HBCT_TrkData.txt");
		debug_file = fopen(file, "a+");
		fprintf(debug_file, msg);
		fclose(debug_file);
	}
}

// Metodo que retorna a data e hora local
char * novaEdt::CurrentTime (void)
{
		SYSTEMTIME st;
		GetSystemTime(&st);

		time_t t = time(0);
		struct tm * now = localtime( &t );

		static char date[100];
		char temp[5];
		int nNum = 0;

		strcpy(date,"");
		nNum = now->tm_year+1900;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"-");

		nNum = now->tm_mon+1;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"-");

		nNum = now->tm_mday;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date," ");

		nNum = now->tm_hour;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,":");

		nNum = now->tm_min;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,":");
		
		nNum = now->tm_sec;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,".");

		nNum = st.wMilliseconds;
		itoa(nNum,temp,10);
		strcat(date,temp);
		strcat(date," - ");

		return date;
}

// Metodo que retorna a data local
char * novaEdt::CurrentDate (void)
{
		time_t t = time(0);
		struct tm * now = localtime( &t );

		static char date[100];
		char temp[5];
		int nNum = 0;

		strcpy(date,"");
		nNum = now->tm_year+1900;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"-");

		nNum = now->tm_mon+1;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"-");

		nNum = now->tm_mday;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);

		return date;
}

// Metodo que retorna a data e hora local em configuracao para impressao
char * novaEdt::CurrentTimePrint (void)
{
		time_t t = time(0);
		struct tm * now = localtime( &t );

		static char date[100];
		char temp[5];
		int nNum = 0;

		strcpy(date,"");
		nNum = now->tm_mday;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"/");
                         
		nNum = now->tm_mon+1;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"/");

		nNum = now->tm_year+1900;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,", ");

		nNum = now->tm_hour;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,":");

		nNum = now->tm_min;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,":");

		nNum = now->tm_sec;
		itoa(nNum,temp,10);
		if (nNum <= 9) strcat(date,"0");
		strcat(date,temp);
		strcat(date,"");

		return date;
}

