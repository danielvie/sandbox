/*
 * imprimir.cpp
 *
 *  Created on: 27/10/2015
 *      Author: DVieira
 */

#include <imprimir.h>



imprimir::imprimir(novaEdt *nedt) {
	// TODO Auto-generated constructor stub
	this->nedt = nedt;
	this->txt = (char*)malloc(800*sizeof(char));
}

void imprimir::dadosLancamento(){
	// MOSTRANDO VALORES INICIAIS
	printf("sec_bal: %d\n",nedt->edtData.Sec_bal);

	printf("--------------------------------------------\n");
	printf("posicao lancadora: \n");

	printf("Este : %.2f\n",nedt->edtData.Elau);
	printf("Norte: %.2f\n",nedt->edtData.Nlau);
	printf("Alt  : %.2f\n",nedt->edtData.Alt_launch);

	printf("coordenadas alvo:\n");
	printf("Este : %.2f\n",nedt->edtData.Etarg);
	printf("Norte: %.2f\n",nedt->edtData.Ntarg);
	printf("Alt  : %.2f\n",nedt->edtData.Altarg);
	printf("--------------------------------------------\n");
}

void imprimir::estimacaoVento(){
	sprintf(this->txt,"imprimir::estimacaoVento\n");
	sprintf(this->txt + strlen(this->txt),"VentoTH XY: %.2f; %.2f\n",nedt->edtData.Vweth, nedt->edtData.Vwnth);
	
	nedt->voarCompleto(nedt->tempoQueima*2);
	double velocidadeFimDeQueima[3] = {nedt->stState.VXN, nedt->stState.VYN, nedt->stState.VZN};

	sprintf(this->txt + strlen(this->txt), "Velocidade rastreio : [ %6.2f %7.2f ]\n", nedt->velocidadeFimDeQueima[0], nedt->velocidadeFimDeQueima[1]);
	sprintf(this->txt + strlen(this->txt), "Velocidade simulada : [ %6.2f %7.2f ]\n", nedt->stState.VXN, nedt->stState.VYN);
	sprintf(this->txt + strlen(this->txt), "Erro                : [ %6.2f %7.2f ]\n", velocidadeFimDeQueima[0]-nedt->velocidadeFimDeQueima[0], velocidadeFimDeQueima[1]-nedt->velocidadeFimDeQueima[1]);
	sprintf(this->txt + strlen(this->txt), "\n");

	nedt->voarCompleto();

	sprintf(this->txt + strlen(this->txt),"VentoTH XY: %.2f; %.2f\n",nedt->edtData.Vweff, nedt->edtData.Vwnff);

	sprintf(this->txt + strlen(this->txt), "Impacto extrapolado : [ %9.2f %10.2f %7.2f ]\n", nedt->posicaoFimDeVoo[0], nedt->posicaoFimDeVoo[1], nedt->posicaoFimDeVoo[2]);
	sprintf(this->txt + strlen(this->txt), "Impacto simulado    : [ %9.2f %10.2f %7.2f ]\n", nedt->posicaoImpacto[0], nedt->posicaoImpacto[1], nedt->posicaoImpacto[2]);
	sprintf(this->txt + strlen(this->txt), "Erro                : [ %9.2f %10.2f %7.2f ]\n", nedt->posicaoFimDeVoo[0]-nedt->posicaoImpacto[0], nedt->posicaoFimDeVoo[1]-nedt->posicaoImpacto[1],nedt->posicaoFimDeVoo[2]-nedt->posicaoImpacto[2]);

	sprintf(this->txt + strlen(this->txt), "\n");

	sprintf(this->txt + strlen(this->txt), "Elev: %.1f\tAzi: %.1f\n",nedt->edtData.Elev_tiro, nedt->edtData.Azim_tiro);
	sprintf(this->txt + strlen(this->txt), "Desvio Alcance: %.2f\n", nedt->calcularDesvioAlcance());
	sprintf(this->txt + strlen(this->txt), "Desvio Lateral: %.2f\n", nedt->calcularDesvioLateral());
	sprintf(this->txt + strlen(this->txt), "\n");

	printf("%s\n",this->txt);
}

void imprimir::resultados(){
	double fuze = this->nedt->Fusetime;
	// fuze = (fuze < 1e5)?fuze:0.0;

	sprintf(this->txt,"RESULTADOS:\n");
	sprintf(this->txt+strlen(this->txt),"Elev: %6.1f",this->nedt->edtData.Elev_tiro);
	sprintf(this->txt+strlen(this->txt),"   ");
	sprintf(this->txt+strlen(this->txt),"Azi: %6.1f",this->nedt->edtData.Azim_tiro);
	sprintf(this->txt+strlen(this->txt),"   ");
	sprintf(this->txt+strlen(this->txt),"Fuze: %6.1f\n",fuze);

	sprintf(this->txt+strlen(this->txt),"FimDeVoo          : [ %9.2f %11.2f %9.2f ]\n",this->nedt->posicaoFimDeVoo[0],this->nedt->posicaoFimDeVoo[1],this->nedt->posicaoFimDeVoo[2]);
	sprintf(this->txt+strlen(this->txt),"Impacto           : [ %9.2f %11.2f %9.2f ]\n",this->nedt->posicaoImpacto[0],this->nedt->posicaoImpacto[1],this->nedt->posicaoImpacto[2]);
	sprintf(this->txt+strlen(this->txt),"Alvo              : [ %9.2f %11.2f %9.2f ]\n",this->nedt->edtData.Etarg,this->nedt->edtData.Ntarg,this->nedt->edtData.Altarg);
	sprintf(this->txt+strlen(this->txt),"Impacto - Alvo    : [ %9.2f %11.2f %9.2f ]\n",
		this->nedt->posicaoImpacto[0] - this->nedt->edtData.Etarg,
		this->nedt->posicaoImpacto[1] - this->nedt->edtData.Ntarg,
		this->nedt->posicaoImpacto[2] - this->nedt->edtData.Altarg);
	sprintf(this->txt+strlen(this->txt),"Apogeu            : %.2f\n", this->nedt->apogeu);
	sprintf(this->txt+strlen(this->txt),"Alcance           : %.2f\n", this->nedt->calcularAlcance());
	sprintf(this->txt+strlen(this->txt),"Desvio Alcance    : %.2f\n", this->nedt->calcularDesvioAlcance());
	sprintf(this->txt+strlen(this->txt),"Desvio Lateral    : %.2f\n", this->nedt->calcularDesvioLateral());
	sprintf(this->txt+strlen(this->txt),"Valor de fusetime : %.2f\n", this->nedt->Fusetime);
	sprintf(this->txt+strlen(this->txt),"Valor de hejec    : %.2f\n", this->nedt->Hejec);
	printf(this->txt);
}

void imprimir::fog(int fog){

	switch(fog){
	case 1: 
		sprintf(this->txt,"fog: SS_09TS");
		break;
	case 2: 
		sprintf(this->txt,"fog: SS_30");
		break;
	case 3: 
		sprintf(this->txt,"fog: SS_40");
		break;
	case 4: 
		sprintf(this->txt,"fog: SS_60");
		break;
	case 5: 
		sprintf(this->txt,"fog: SS_80");
		break;
	case 6:
		sprintf(this->txt,"fog: SS_40G");
		break;
	case 7:
		sprintf(this->txt,"fog: RHAN");
		break;
	default:
		sprintf(this->txt,"fog: invalido!");
		break;
	}
	printf("%s\n",this->txt);
}

void imprimir::elementos(){
	sprintf(this->txt," imprimir::elementos\n");
	sprintf(this->txt + strlen(this->txt),"Elevacao: %.2f\n",nedt->edtData.Elev_tiro);
	sprintf(this->txt + strlen(this->txt),"Azimute : %.2f\n",nedt->edtData.Azim_tiro);
	printf("%s\n",this->txt);
}

void imprimir::range() {
	sprintf(this->txt,"imprimir::range\n");
	sprintf(this->txt + strlen(this->txt),"rangeMin: %.2f\n",this->nedt->rangeMin);
	sprintf(this->txt + strlen(this->txt),"rangeMax: %.2f",this->nedt->rangeMax*1.0035);
	printf("%s\n",this->txt);
}

void imprimir::posicaoImpacto() {
	sprintf(this->txt,"posicaoImpacto\n");
	sprintf(this->txt + strlen(this->txt),"Etarg: %.2f\n",nedt->edtData.Etarg);
	sprintf(this->txt + strlen(this->txt),"Ntarg: %.2f\n",nedt->edtData.Ntarg);
	sprintf(this->txt + strlen(this->txt),"posicaoFimDeVooE: %.2f\n",nedt->posicaoFimDeVoo[0]);
	sprintf(this->txt + strlen(this->txt),"posicaoFimDeVooN: %.2f\n",nedt->posicaoFimDeVoo[1]);
	sprintf(this->txt + strlen(this->txt),"diffE: %.2f\n",nedt->posicaoFimDeVoo[0]-nedt->edtData.Etarg);
	sprintf(this->txt + strlen(this->txt),"diffN: %.2f\n",nedt->posicaoFimDeVoo[1]-nedt->edtData.Ntarg);

	printf("%s\n",this->txt);
}

void imprimir::erro(struct TShot shot) {
	switch (shot.Error) {
		case BALISTIC_ERROR001:
			sprintf(this->txt,"ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DO ALVO!");
			break;
		case BALISTIC_ERROR002:
			sprintf(this->txt,"ALTITUDE DO APOGEU ESTA ABAIXO DA ALTITUDE DE EJECAO!");
			break;
		case BALISTIC_ERROR003:
			sprintf(this->txt,"erro: FIRING RANGE TOO SHORT!");
			break;
		case BALISTIC_ERROR004:
			sprintf(this->txt,"erro: FIRING RANGE TOO LONG!");
			break;
		default:
			sprintf(this->txt,"NAO HA ERROS!\n");
			break;
	}
	printf("%s\n",this->txt);
}
