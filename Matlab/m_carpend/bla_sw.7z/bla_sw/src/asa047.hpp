#ifndef __NELMIN__
#define __NELMIN__

void nelmin ( double fn ( double x[], void *param ), void *param, int n, double start[], double xmin[],
  double *ynewlo, double reqmin, double step[], int konvge, int kcount, 
  int *icount, int *numres, int *ifault );

#endif // __NELMIN__
