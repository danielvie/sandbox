/*
 * imprimir.h
 *
 *  Created on: 27/10/2015
 *      Author: DVieira
 */

#ifndef IMPRIMIR_H_
#define IMPRIMIR_H_

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>

#include "novaedt.h"

class imprimir {
public:
	// atributos
	char* txt;
	novaEdt *nedt;

	// metodos
	imprimir(novaEdt *nedt);
	void dadosLancamento();
	void estimacaoVento();
	void resultados();
	void fog(int fog);
	void elementos();
	void range();
	void posicaoImpacto();
	void erro(struct TShot shot);
};

#endif /* IMPRIMIR_H_ */
