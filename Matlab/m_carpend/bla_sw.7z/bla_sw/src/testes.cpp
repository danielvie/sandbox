/*
 * testes.cpp
 *
 *  Created on: 07/08/2015
 *      Author: avibras
 */

#include "testes.h"
#include "imprimir.h"

int testeLancamentoSimples(novaEdt *nedt){
	//  Selecao foguete:
	int fog = SS_30;
	nedt->ConfigEdt(fog);

	//  Elementos de Tiro:
	nedt->edtData.Elau       = 352742.0; // Leste lancadora
	nedt->edtData.Nlau       = 9138743.0; // Norte lancadora
	nedt->edtData.Alt_launch = 12.0; // Alti. lancadora
	nedt->edtData.Latitude   = 5.0; // Latitude

	nedt->edtData.Etarg      = 343426.0; // Leste alvo
	nedt->edtData.Ntarg      = 9101387.0; // Norte alvo
	nedt->edtData.Altarg     = 0.0; // Alti. alvo

	nedt->edtData.Alt_met    = 10.0; // Alti. MET
	nedt->edtData.Altfg      = 10.0; // Alti. UCF

	nedt->edtData.T0         = 26.5; // Temperatura
	nedt->edtData.Proptemp   = 26.8; // T. Propelente
	nedt->edtData.P0         = 1012.1; // Pressao

	nedt->edtData.Sec_bal    = 0; // Balistica Sec.

	nedt->edtData.Latitude   = 5.0; // Latitude

	// Vento de Superficie:
	nedt->edtData.Vws        = 12.5; // Vel.Vento Sup.
	nedt->edtData.Azws       = 5400.0; // Az. Vento Sup.

	// METCM:
	nedt->edtData.Metcm_included = 1;
	nedt->edtData.Natm = 25;

	nedt->edtData.Vwmetcm[0] = 7.0; nedt->edtData.Vwmetcm[1] = 11.0; nedt->edtData.Vwmetcm[2] = 13.0; nedt->edtData.Vwmetcm[3] = 17.0; nedt->edtData.Vwmetcm[4] = 15.0; nedt->edtData.Vwmetcm[5] = 11.0; nedt->edtData.Vwmetcm[6] = 17.0; nedt->edtData.Vwmetcm[7] = 13.0; nedt->edtData.Vwmetcm[8] = 9.0; nedt->edtData.Vwmetcm[9] = 17.0; nedt->edtData.Vwmetcm[10] = 12.0; nedt->edtData.Vwmetcm[11] = 11.0; nedt->edtData.Vwmetcm[12] = 19.0; nedt->edtData.Vwmetcm[13] = 24.0; nedt->edtData.Vwmetcm[14] = 28.0; nedt->edtData.Vwmetcm[15] = 36.0; nedt->edtData.Vwmetcm[16] = 35.0; nedt->edtData.Vwmetcm[17] = 30.0; nedt->edtData.Vwmetcm[18] = 38.0; nedt->edtData.Vwmetcm[19] = 46.0; nedt->edtData.Vwmetcm[20] = 31.0; nedt->edtData.Vwmetcm[21] = 25.0; nedt->edtData.Vwmetcm[22] = 14.0; nedt->edtData.Vwmetcm[23] = 7.0; nedt->edtData.Vwmetcm[24] = 10.0; nedt->edtData.Vwmetcm[25] = 8.0; 
	nedt->edtData.Azwmetcm[0] = 2170.0; nedt->edtData.Azwmetcm[1] = 2210.0; nedt->edtData.Azwmetcm[2] = 1680.0; nedt->edtData.Azwmetcm[3] = 1820.0; nedt->edtData.Azwmetcm[4] = 2000.0; nedt->edtData.Azwmetcm[5] = 1870.0; nedt->edtData.Azwmetcm[6] = 1500.0; nedt->edtData.Azwmetcm[7] = 1240.0; nedt->edtData.Azwmetcm[8] = 1220.0; nedt->edtData.Azwmetcm[9] = 1250.0; nedt->edtData.Azwmetcm[10] = 1250.0; nedt->edtData.Azwmetcm[11] = 960.0; nedt->edtData.Azwmetcm[12] = 1570.0; nedt->edtData.Azwmetcm[13] = 1700.0; nedt->edtData.Azwmetcm[14] = 2180.0; nedt->edtData.Azwmetcm[15] = 2330.0; nedt->edtData.Azwmetcm[16] = 1730.0; nedt->edtData.Azwmetcm[17] = 1360.0; nedt->edtData.Azwmetcm[18] = 930.0; nedt->edtData.Azwmetcm[19] = 980.0; nedt->edtData.Azwmetcm[20] = 1310.0; nedt->edtData.Azwmetcm[21] = 1170.0; nedt->edtData.Azwmetcm[22] = 1990.0; nedt->edtData.Azwmetcm[23] = 1120.0; nedt->edtData.Azwmetcm[24] = 3390.0; nedt->edtData.Azwmetcm[25] = 5030.0; 
	nedt->edtData.Tent[0] = 301.1; nedt->edtData.Tent[1] = 299.7; nedt->edtData.Tent[2] = 297.4; nedt->edtData.Tent[3] = 294.0; nedt->edtData.Tent[4] = 291.0; nedt->edtData.Tent[5] = 288.2; nedt->edtData.Tent[6] = 288.8; nedt->edtData.Tent[7] = 286.7; nedt->edtData.Tent[8] = 284.9; nedt->edtData.Tent[9] = 281.9; nedt->edtData.Tent[10] = 277.8; nedt->edtData.Tent[11] = 274.5; nedt->edtData.Tent[12] = 270.3; nedt->edtData.Tent[13] = 264.4; nedt->edtData.Tent[14] = 258.9; nedt->edtData.Tent[15] = 251.4; nedt->edtData.Tent[16] = 243.4; nedt->edtData.Tent[17] = 236.1; nedt->edtData.Tent[18] = 227.9; nedt->edtData.Tent[19] = 220.3; nedt->edtData.Tent[20] = 213.6; nedt->edtData.Tent[21] = 205.1; nedt->edtData.Tent[22] = 199.4; nedt->edtData.Tent[23] = 198.0; nedt->edtData.Tent[24] = 196.8; nedt->edtData.Tent[25] = 200.1; 
	nedt->edtData.Pent[0] = 1009.0; nedt->edtData.Pent[1] = 997.0; nedt->edtData.Pent[2] = 969.0; nedt->edtData.Pent[3] = 925.0; nedt->edtData.Pent[4] = 873.0; nedt->edtData.Pent[5] = 823.0; nedt->edtData.Pent[6] = 775.0; nedt->edtData.Pent[7] = 731.0; nedt->edtData.Pent[8] = 688.0; nedt->edtData.Pent[9] = 648.0; nedt->edtData.Pent[10] = 610.0; nedt->edtData.Pent[11] = 573.0; nedt->edtData.Pent[12] = 522.0; nedt->edtData.Pent[13] = 459.0; nedt->edtData.Pent[14] = 403.0; nedt->edtData.Pent[15] = 352.0; nedt->edtData.Pent[16] = 307.0; nedt->edtData.Pent[17] = 266.0; nedt->edtData.Pent[18] = 230.0; nedt->edtData.Pent[19] = 197.0; nedt->edtData.Pent[20] = 168.0; nedt->edtData.Pent[21] = 143.0; nedt->edtData.Pent[22] = 121.0; nedt->edtData.Pent[23] = 102.0; nedt->edtData.Pent[24] = 86.0; nedt->edtData.Pent[25] = 72.0; 

	// Ventos Estimados:
	nedt->edtData.Vweth = 0.0;
	nedt->edtData.Vwnth = 0.0;
	nedt->edtData.Vweff = 44.76;
	nedt->edtData.Vwnff = 15.18;
	nedt->Vweth = nedt->edtData.Vweth;
	nedt->Vwnth = nedt->edtData.Vwnth;
	nedt->Vweff = nedt->edtData.Vweff;
	nedt->Vwnff = nedt->edtData.Vwnff;


	//  Calculo de Tiro :
	nedt->edtData.Elev_tiro      = 1013.0;
	// nedt->edtData.Azim_tiro      = 3471.0;
	nedt->edtData.Fusetime_input = 129.0;
	

	struct TShot shot;
	shot = nedt->calcularTiro2();
	// nedt->calcularAlcanceMinimo();
	// shot = nedt->voarCompleto();


// ===============================================================================
	
// ===============================================================================
	// double elev = 950.0;
	// for (;;) {

	// 	nedt->edtData.Elev_tiro = elev;
	// 	shot = nedt->voarCompleto();
		
	// 	printf("elevacao: %6.1f mils, alcance: %.1f metros\n", shot.El, shot.Range);
		
	// 	elev += 2.0;
	// 	if (elev > 1102.0) {
	// 		break;
	// 	}
	// }

	
	imprimir p(nedt);

	printf("\n");
	printf("alc max : %f\n", nedt->rangeMax);
	printf("alc min : %f\n", nedt->rangeMin);
	printf("elev max: %f\n", nedt->DDTDLL.Elevmax/0.05625);
	printf("\n");
	p.fog(fog);
	p.resultados();
	printf("\n");
	p.erro(shot);
	return 1;
}