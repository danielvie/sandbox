#include <iostream>
#include "array.h"
using namespace std;

int main()
{
	Array rij(10, 0);
		// 10 integers, initialised to 0

    // Remove // as your design proceeds
	// row[5]=7;

  	// int i=row[4];

}
