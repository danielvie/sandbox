#pragma once
#include <iostream>
#include <string>

class animal {
public:
    void wag_tail(){}
};

class elephant {
public:
    void wag_tail(){}
};

class door_knob {
public:
    void give_hand(){}
};

class robin {
public:
    void flap_wings(){}
    void wag_tail(){}
};

class bird {
public:
    void flap_wings(){}
    void wag_tail(){}
};

class cat {
public:
    void meow(){}
    void wag_tail(){}
};

class dog {
public:
    void bark(){}
    void wag_tail(){}
};

class Aethalops {
public:
    void bark(){}
    void flap_wings(){}
    void wag_tail(){}
};
