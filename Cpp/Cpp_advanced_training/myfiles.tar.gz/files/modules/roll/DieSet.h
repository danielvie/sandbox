// Definition of the DieSet class
