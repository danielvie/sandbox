// Definition of the Die class
