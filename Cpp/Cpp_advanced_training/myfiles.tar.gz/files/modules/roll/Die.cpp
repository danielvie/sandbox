// implementation of the Die class
