// implementation of the DieSet class
