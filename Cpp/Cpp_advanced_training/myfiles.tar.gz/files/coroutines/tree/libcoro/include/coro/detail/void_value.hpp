#pragma once

namespace coro::detail
{
struct void_value
{
};

} // namespace coro::detail
