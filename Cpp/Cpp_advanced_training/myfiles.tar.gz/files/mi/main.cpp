#include "foodtruck.h"
#include "ownership.h"



int main() {
    FoodTruck ft;

    ft.H
    
    std::cout << "dfasdfasdf\n";
}
