#ifndef SQREFUNC_H
#define SQREFUNC_H

typedef double (*sqre)(double) ;

#endif
