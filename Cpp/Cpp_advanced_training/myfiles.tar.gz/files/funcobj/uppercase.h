#ifndef UPPERCASE_H
#define UPPERCASE_H
// add your upfilter class here
#endif
